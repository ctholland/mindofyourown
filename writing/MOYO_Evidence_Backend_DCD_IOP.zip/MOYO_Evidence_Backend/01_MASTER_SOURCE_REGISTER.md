# DATA CENTER DISCONNECT — MASTER SOURCE REGISTER
**Project:** The Data Center Disconnect and the Dystopian Debacle / The Architecture of Interoperable Power  
**Author:** C.T. Holland / Mind Of Your Own®  
**Status:** Evidence-backend working register  
**Built from:** the current main paper and the current expanded companion paper.  

## Purpose
This is the stable source layer beneath the two papers. Source IDs should remain stable even if Christofer later makes human edits to the prose. The next backend document—the Master Claim Ledger—should cite these source IDs rather than depending on paragraph position.

## Evidence Handling
- **Primary / official record** — legislation, court records, agency publications, procurement records, SEC filings, official reports.
- **Company / institutional primary** — first-party product documentation, corporate announcements, institutional materials. Useful for what an entity says or offers; not independent verification of disputed claims.
- **Intergovernmental / analytical** — institutional research such as IEA.
- **Secondary journalism** — reporting used for documented interviews, leaked records, contextual reporting, or facts not available in a public primary source.
- A source can support a bounded claim without supporting every inference made around that claim.

## Register
| ID | Source | Class | Used in | Paper ref(s) |
|---|---|---|---|---|
| SRC-001 | International Energy Agency, “Energy Demand from AI,” *Energy and AI*, estimates global data-center electricity consumption at about 415 TWh in 2024 and projects roughly 945 TWh by 2030 in its base case.iea | Intergovernmental / analytical | Main paper | MAIN-01 |
| SRC-002 | U.S. Department of Energy, “DOE Releases New Report Evaluating Increase in Electricity Demand from Data Centers,” summarizing the 2024 Lawrence Berkeley National Laboratory data-center energy-use report.energy | Primary / official record | Both papers | MAIN-02, COMP-16 |
| SRC-003 | Lawrence Berkeley National Laboratory, *2024 United States Data Center Energy Usage Report*, including projected 2028 electricity-consumption and utilization assumptions.eta-publications.lbl | Primary / official record | Main paper | MAIN-03 |
| SRC-004 | Lawrence Berkeley National Laboratory, *United States Data Center Energy Usage Report: 2025 Update*, including updated 2024 consumption and 2030 scenario estimates.energy | Primary / official record | Both papers | MAIN-04, COMP-17 |
| SRC-005 | International Energy Agency, “Artificial Intelligence — Topics,” on the localized concentration of data-center demand and state-level and Irish electricity shares.iea | Intergovernmental / analytical | Both papers | MAIN-05, COMP-18 |
| SRC-006 | International Energy Agency, “Energy Supply for AI,” on projected generation sources serving data-center demand.iea | Intergovernmental / analytical | Main paper | MAIN-06 |
| SRC-007 | Virginia Joint Legislative Audit and Review Commission, “Data Centers in Virginia,” on factors contributing to Northern Virginia’s market concentration and the state sales-and-use-tax exemption.jlarc.virginia | Primary / official record | Main paper | MAIN-07 |
| SRC-008 | Federal Energy Regulatory Commission, “FERC Launches Aggressive Targeted Action to Speed Large Load Integration,” on the review of grid-operator tariffs for data centers and other large loads.ferc | Primary / official record | Main paper | MAIN-08 |
| SRC-009 | Federal Energy Regulatory Commission-related reporting and legal analysis addressing cost-recovery, financial-assurance, and ratepayer-protection questions in large-load interconnection.utilitydive+1 | Other / verify classification | Main paper | MAIN-09 |
| SRC-010 | Microsoft, *2025 Annual Report*, on its global data-center footprint and continuing AI and cloud capital expenditures.sec+1 | Other / verify classification | Main paper | MAIN-10 |
| SRC-011 | Google Cloud, “Google Cloud Coming Soon to Palantir FedStart,” on the availability of FedStart-based public-sector deployments on Google Cloud infrastructure.cloud.google | Company / institutional primary | Main paper | MAIN-11 |
| SRC-012 | Palantir, “FedStart,” describing its federal deployment offering.palantir | Company / institutional primary | Main paper | MAIN-12 |
| SRC-013 | U.S. General Services Administration, SAM.gov procurement notice for FAA Logistics Center data modernization, describing Palantir Foundry’s intended data-integration and analytics functions.sam | Primary / official record | Both papers | MAIN-13, COMP-13 |
| SRC-014 | National Institute of Standards and Technology, SP 800-63A-4, *Digital Identity Guidelines: Identity Proofing and Enrollment*.csrc.nist | Primary / official record | Main paper | MAIN-14 |
| SRC-015 | National Institute of Standards and Technology, SP 800-63C-4, *Digital Identity Guidelines: Federation and Assertions*.csrc.nist | Primary / official record | Both papers | MAIN-15, COMP-12 |
| SRC-016 | U.S. Government Accountability Office, *Facial Recognition Technology: Federal Agencies’ Use and Related Privacy and Accuracy Issues*, on federal use and access to facial-recognition systems owned by other enti… | Primary / official record | Both papers | MAIN-16, COMP-14 |
| SRC-017 | Federal Reserve, remarks by Vice Chair for Supervision Michael Barr on FedNow and CBDC research, including the distinction between FedNow and a CBDC and the need for authorizing legislation for any U.S. CBDC is… | Primary / official record | Main paper | MAIN-17 |
| SRC-018 | Social Security Administration, “The Story of the Social Security Number,” and SSA historical reporting on the SSN’s original purpose and expansion as a broadly used identifier | Other / verify classification | Main paper | MAIN-18 |
| SRC-019 | U.S. House of Representatives, **H.R. 8800, National Defense Authorization Act for Fiscal Year 2027**, 119th Cong., House-passed text, § 219, “United States–Israel Defense Technology Cooperation Initiative,” Ju… | Primary / official record | Companion paper | COMP-01 |
| SRC-020 | U.S. Senate, **S. 4784, National Defense Authorization Act for Fiscal Year 2027**, 119th Cong., § 1217, “United States–Israel Framework for Upgraded Technologies, Unified Research, and Enhanced Security Act of … | Primary / official record | Companion paper | COMP-02 |
| SRC-021 | U.S. House of Representatives, **Congressional Record**, vol. 172, no. 120, July 22, 2026, House consideration of H.R. 8800, including adoption of Luna Amendment No. 320 striking “integration” from the opening … | Primary / official record | Companion paper | COMP-03 |
| SRC-022 | U.S. Senate Committee on Armed Services, **FY2027 NDAA Executive Summary**, 2026, U.S. Senate Committee on Armed Services, **FY2027 NDAA Report Language**, 2026, | Primary / official record | Companion paper | COMP-04 |
| SRC-023 | U.S. Senate, **S. 4615, Intelligence Authorization Act for Fiscal Year 2027**, 119th Cong., § 622, “United States–Israel intelligence sharing enhancement,” May 2026, | Primary / official record | Companion paper | COMP-05 |
| SRC-024 | U.S. Senate Select Committee on Intelligence, **Intelligence Authorization Act for Fiscal Year 2027, as Reported on May 20, 2026**, May 20, 2026, Legislative status and final section numbering remain subject to… | Primary / official record | Companion paper | COMP-06 |
| SRC-025 | Palantir Technologies Inc., **Annual Report on Form 10-K for the Fiscal Year Ended December 31, 2025**, filed with the U.S. Securities and Exchange Commission, February 2026, See Item 1, “Business,” and custome… | Primary / official record | Companion paper | COMP-07, COMP-09 |
| SRC-026 | Palantir Technologies, **Platforms**, including documentation for Gotham, Foundry, Apollo, AIP, and Ontology, accessed September 27, 2026, For the company’s fuller description of platform functions, access cont… | Primary / official record | Companion paper | COMP-08 |
| SRC-027 | U.S. Immigration and Customs Enforcement, **Privacy Impact Assessment Update for Investigative Case Management**, DHS/ICE/PIA-045(b), May 2020, U.S. House Committee on Oversight and Reform, **“The Surveillance … | Primary / official record | Companion paper | COMP-10 |
| SRC-028 | Palantir Technologies, **“Palantir and the Israeli Ministry of Defense Enter Strategic Partnership,”** January 12, 2024, company announcement, see also CTech, **“Palantir Supplying Israel With Technology to Hel… | Company / institutional primary | Companion paper | COMP-11 |
| SRC-029 | Flock Safety, **Law Enforcement** product and policy materials, accessed September 27, 2026, Access, retention, sharing, and audit practices vary by agency policy, contract, and jurisdiction | Company / institutional primary | Companion paper | COMP-15 |
| SRC-030 | U.S. Department of Defense, **“DoD Awards Joint Warfighting Cloud Capability Contracts,”** December 7, 2022, The award covered enterprise cloud capability across unclassified, secret, and top-secret classificat… | Primary / official record | Companion paper | COMP-19 |
| SRC-031 | U.S. Department of Homeland Security, **National Network of Fusion Centers Fact Sheet**, accessed September 27, 2026, U.S. Senate Permanent Subcommittee on Investigations, **Federal Support for and Involvement … | Primary / official record | Companion paper | COMP-20 |
| SRC-032 | U.S. Department of State, **“Secretary of State Marco Rubio Remarks to the Press,”** March 28, 2025, Rubio stated that the United States may deny or revoke visas where it determines a visa holder’s activities a… | Primary / official record | Companion paper | COMP-21 |
| SRC-033 | *Khalil v. Joyce*, No. 25-CV-1935 (JMF), Opinion and Order, U.S. District Court for the Southern District of New York, March 19, 2025, The court recounted that Khalil, a lawful permanent resident, alleged retal… | Primary / official record | Companion paper | COMP-22 |
| SRC-034 | Dell Cameron and Yulia Almazova, **“Leak Exposes Members of Peter Thiel’s Secretive ‘Dialog’ Society,”** *WIRED*, June 16, 2026, The article reports that *WIRED* independently verified internal records and a 20… | Secondary journalism | Companion paper | COMP-23 |
| SRC-035 | Palantir Technologies, **Company History and Leadership**, accessed September 27, 2026, 8VC, **Team: Joe Lonsdale**, accessed September 27, 2026, Founders Fund, **Peter Thiel**, accessed September 27, 2026, The… | Company / institutional primary | Companion paper | COMP-24 |
| SRC-036 | Executive Order 14188, **Additional Measures To Combat Anti-Semitism**, January 29, 2025, GovInfo, U.S. Department of Justice, **“Justice Department Announces Formation of Task Force to Combat Anti-Semitism,”**… | Primary / official record | Companion paper | COMP-25 |
| SRC-037 | Mike Allen, **“Scoop: Dialog, a secretive forum, plans D.C.-area campus,”** Axios, August 7, 2025, updated June 2026, Axios identifies Peter Thiel and Auren Hoffman as Dialog’s founders and lists Senator Cory B… | Secondary journalism | Companion paper | COMP-26 |
| SRC-038 | Dell Cameron, Dhruv Mehrotra, and Yulia Almazova, **“How the Peter Thiel-Linked Dialog Club Secretly Ranks Its Members,”** *WIRED*, June 18, 2026, *WIRED* reports that Dialog uses internal rankings tied to weal… | Secondary journalism | Companion paper | COMP-27 |
| SRC-039 | Johana Bhuiyan, **“Key Trump allies and Musk on leaked list for secretive Peter Thiel retreat,”** *The Guardian*, June 20, 2026, updated June 22, 2026, *The Guardian* reported that it independently verified the… | Secondary journalism | Companion paper | COMP-28 |
| SRC-040 | Dell Cameron and Yulia Almazova, **“The Pentagon Is Looking Into the Dialog Data Exposure for Unmasking National Security Officials,”** *WIRED*, June 2026, *WIRED* reported that exposed Dialog records included … | Secondary journalism | Companion paper | COMP-29 |

## Full Citations and URLs

### SRC-001
**Used in:** Main paper — MAIN-01  
**Class:** Intergovernmental / analytical  
**Citation as carried in paper:** International Energy Agency, “Energy Demand from AI,” *Energy and AI*, estimates global data-center electricity consumption at about 415 TWh in 2024 and projects roughly 945 TWh by 2030 in its base case.iea — https://www.iea.org/reports/energy-and-ai/energy-demand-from-ai  
**URL(s):**
- https://www.iea.org/reports/energy-and-ai/energy-demand-from-ai

### SRC-002
**Used in:** Both papers — MAIN-02, COMP-16  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. Department of Energy, “DOE Releases New Report Evaluating Increase in Electricity Demand from Data Centers,” summarizing the 2024 Lawrence Berkeley National Laboratory data-center energy-use report.energy — https://www.energy.gov/articles/doe-releases-new-report-evaluating-increase-electricity-demand-data-centers  
**URL(s):**
- https://www.energy.gov/articles/doe-releases-new-report-evaluating-increase-electricity-demand-data-centers
- https://eta-publications.lbl.gov/sites/default/files/2024-12/lbnl-2024-united-states-data-center-energy-usage-report_1.pdf

### SRC-003
**Used in:** Main paper — MAIN-03  
**Class:** Primary / official record  
**Citation as carried in paper:** Lawrence Berkeley National Laboratory, *2024 United States Data Center Energy Usage Report*, including projected 2028 electricity-consumption and utilization assumptions.eta-publications.lbl — https://eta-publications.lbl.gov/sites/default/files/2024-12/lbnl-2024-united-states-data-center-energy-usage-report_1.pdf  
**URL(s):**
- https://eta-publications.lbl.gov/sites/default/files/2024-12/lbnl-2024-united-states-data-center-energy-usage-report_1.pdf

### SRC-004
**Used in:** Both papers — MAIN-04, COMP-17  
**Class:** Primary / official record  
**Citation as carried in paper:** Lawrence Berkeley National Laboratory, *United States Data Center Energy Usage Report: 2025 Update*, including updated 2024 consumption and 2030 scenario estimates.energy — https://www.energy.gov/documents/united-states-data-center-energy-usage-report-2025-update  
**URL(s):**
- https://www.energy.gov/documents/united-states-data-center-energy-usage-report-2025-update

### SRC-005
**Used in:** Both papers — MAIN-05, COMP-18  
**Class:** Intergovernmental / analytical  
**Citation as carried in paper:** International Energy Agency, “Artificial Intelligence — Topics,” on the localized concentration of data-center demand and state-level and Irish electricity shares.iea — https://www.iea.org/topics/artificial-intelligence  
**URL(s):**
- https://www.iea.org/topics/artificial-intelligence

### SRC-006
**Used in:** Main paper — MAIN-06  
**Class:** Intergovernmental / analytical  
**Citation as carried in paper:** International Energy Agency, “Energy Supply for AI,” on projected generation sources serving data-center demand.iea — https://www.iea.org/reports/energy-and-ai/energy-supply-for-ai  
**URL(s):**
- https://www.iea.org/reports/energy-and-ai/energy-supply-for-ai

### SRC-007
**Used in:** Main paper — MAIN-07  
**Class:** Primary / official record  
**Citation as carried in paper:** Virginia Joint Legislative Audit and Review Commission, “Data Centers in Virginia,” on factors contributing to Northern Virginia’s market concentration and the state sales-and-use-tax exemption.jlarc.virginia — https://jlarc.virginia.gov/landing-2024-data-centers-in-virginia.asp  
**URL(s):**
- https://jlarc.virginia.gov/landing-2024-data-centers-in-virginia.asp

### SRC-008
**Used in:** Main paper — MAIN-08  
**Class:** Primary / official record  
**Citation as carried in paper:** Federal Energy Regulatory Commission, “FERC Launches Aggressive Targeted Action to Speed Large Load Integration,” on the review of grid-operator tariffs for data centers and other large loads.ferc — https://www.ferc.gov/news-events/news/ferc-launches-aggressive-targeted-action-speed-large-load-integration  
**URL(s):**
- https://www.ferc.gov/news-events/news/ferc-launches-aggressive-targeted-action-speed-large-load-integration

### SRC-009
**Used in:** Main paper — MAIN-09  
**Class:** Other / verify classification  
**Citation as carried in paper:** Federal Energy Regulatory Commission-related reporting and legal analysis addressing cost-recovery, financial-assurance, and ratepayer-protection questions in large-load interconnection.utilitydive+1  
**URL:** Not included in current paper note; exact source URL still needs capture.

### SRC-010
**Used in:** Main paper — MAIN-10  
**Class:** Other / verify classification  
**Citation as carried in paper:** Microsoft, *2025 Annual Report*, on its global data-center footprint and continuing AI and cloud capital expenditures.sec+1  
**URL:** Not included in current paper note; exact source URL still needs capture.

### SRC-011
**Used in:** Main paper — MAIN-11  
**Class:** Company / institutional primary  
**Citation as carried in paper:** Google Cloud, “Google Cloud Coming Soon to Palantir FedStart,” on the availability of FedStart-based public-sector deployments on Google Cloud infrastructure.cloud.google — https://cloud.google.com/blog/topics/public-sector/google-public-sector-and-palantir-collaborate-to-bring-google-cloud-to-fedstart  
**URL(s):**
- https://cloud.google.com/blog/topics/public-sector/google-public-sector-and-palantir-collaborate-to-bring-google-cloud-to-fedstart

### SRC-012
**Used in:** Main paper — MAIN-12  
**Class:** Company / institutional primary  
**Citation as carried in paper:** Palantir, “FedStart,” describing its federal deployment offering.palantir — https://www.palantir.com/offerings/fedstart/  
**URL(s):**
- https://www.palantir.com/offerings/fedstart/

### SRC-013
**Used in:** Both papers — MAIN-13, COMP-13  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. General Services Administration, SAM.gov procurement notice for FAA Logistics Center data modernization, describing Palantir Foundry’s intended data-integration and analytics functions.sam — https://sam.gov/workspace/contract/opp/6a09feebd8034839b4e36046aa406bbb/view  
**URL(s):**
- https://sam.gov/workspace/contract/opp/6a09feebd8034839b4e36046aa406bbb/view

### SRC-014
**Used in:** Main paper — MAIN-14  
**Class:** Primary / official record  
**Citation as carried in paper:** National Institute of Standards and Technology, SP 800-63A-4, *Digital Identity Guidelines: Identity Proofing and Enrollment*.csrc.nist — https://csrc.nist.gov/pubs/sp/800/63/a/4/final  
**URL(s):**
- https://csrc.nist.gov/pubs/sp/800/63/a/4/final

### SRC-015
**Used in:** Both papers — MAIN-15, COMP-12  
**Class:** Primary / official record  
**Citation as carried in paper:** National Institute of Standards and Technology, SP 800-63C-4, *Digital Identity Guidelines: Federation and Assertions*.csrc.nist — https://csrc.nist.gov/pubs/sp/800/63/c/4/final  
**URL(s):**
- https://csrc.nist.gov/pubs/sp/800/63/c/4/final

### SRC-016
**Used in:** Both papers — MAIN-16, COMP-14  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. Government Accountability Office, *Facial Recognition Technology: Federal Agencies’ Use and Related Privacy and Accuracy Issues*, on federal use and access to facial-recognition systems owned by other entities.gao — https://www.gao.gov/products/gao-22-106100  
**URL(s):**
- https://www.gao.gov/products/gao-22-106100

### SRC-017
**Used in:** Main paper — MAIN-17  
**Class:** Primary / official record  
**Citation as carried in paper:** Federal Reserve, remarks by Vice Chair for Supervision Michael Barr on FedNow and CBDC research, including the distinction between FedNow and a CBDC and the need for authorizing legislation for any U.S. CBDC issuance.federalreserve — https://www.federalreserve.gov/newsevents/speech/barr20231027a.htm  
**URL(s):**
- https://www.federalreserve.gov/newsevents/speech/barr20231027a.htm

### SRC-018
**Used in:** Main paper — MAIN-18  
**Class:** Other / verify classification  
**Citation as carried in paper:** Social Security Administration, “The Story of the Social Security Number,” and SSA historical reporting on the SSN’s original purpose and expansion as a broadly used identifier.  
**URL:** Not included in current paper note; exact source URL still needs capture.

### SRC-019
**Used in:** Companion paper — COMP-01  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. House of Representatives, **H.R. 8800, National Defense Authorization Act for Fiscal Year 2027**, 119th Cong., House-passed text, § 219, “United States–Israel Defense Technology Cooperation Initiative,” July 22, 2026, https://www.congress.gov/bill/119th-congress/house-bill/8800/text. The House measure had not become enacted law as of September 27, 2026.  
**URL(s):**
- https://www.congress.gov/bill/119th-congress/house-bill/8800/text

### SRC-020
**Used in:** Companion paper — COMP-02  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. Senate, **S. 4784, National Defense Authorization Act for Fiscal Year 2027**, 119th Cong., § 1217, “United States–Israel Framework for Upgraded Technologies, Unified Research, and Enhanced Security Act of 2026,” 2026, https://www.congress.gov/bill/119th-congress/senate-bill/4784/text.  
**URL(s):**
- https://www.congress.gov/bill/119th-congress/senate-bill/4784/text

### SRC-021
**Used in:** Companion paper — COMP-03  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. House of Representatives, **Congressional Record**, vol. 172, no. 120, July 22, 2026, House consideration of H.R. 8800, including adoption of Luna Amendment No. 320 striking “integration” from the opening list in § 219, https://www.govinfo.gov/content/pkg/CREC-2026-07-22/html/CREC-2026-07-22-pt1-PgD759.htm.  
**URL(s):**
- https://www.govinfo.gov/content/pkg/CREC-2026-07-22/html/CREC-2026-07-22-pt1-PgD759.htm

### SRC-022
**Used in:** Companion paper — COMP-04  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. Senate Committee on Armed Services, **FY2027 NDAA Executive Summary**, 2026, https://www.armed-services.senate.gov/imo/media/doc/fy2027_ndaa_exsum.pdf; U.S. Senate Committee on Armed Services, **FY2027 NDAA Report Language**, 2026, https://www.armed-services.senate.gov/imo/media/doc/fy27_ndaa_report_language_committee_filing_version.pdf.  
**URL(s):**
- https://www.armed-services.senate.gov/imo/media/doc/fy2027_ndaa_exsum.pdf
- https://www.armed-services.senate.gov/imo/media/doc/fy27_ndaa_report_language_committee_filing_version.pdf

### SRC-023
**Used in:** Companion paper — COMP-05  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. Senate, **S. 4615, Intelligence Authorization Act for Fiscal Year 2027**, 119th Cong., § 622, “United States–Israel intelligence sharing enhancement,” May 2026, https://www.congress.gov/bill/119th-congress/senate-bill/4615/text.  
**URL(s):**
- https://www.congress.gov/bill/119th-congress/senate-bill/4615/text

### SRC-024
**Used in:** Companion paper — COMP-06  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. Senate Select Committee on Intelligence, **Intelligence Authorization Act for Fiscal Year 2027, as Reported on May 20, 2026**, May 20, 2026, https://www.intelligence.senate.gov/2026/05/20/intelligence-authorization-act-for-fiscal-year-2027-as-reported-on-may-20-2026/. Legislative status and final section numbering remain subject to later congressional action.  
**URL(s):**
- https://www.intelligence.senate.gov/2026/05/20/intelligence-authorization-act-for-fiscal-year-2027-as-reported-on-may-20-2026/

### SRC-025
**Used in:** Companion paper — COMP-07, COMP-09  
**Class:** Primary / official record  
**Citation as carried in paper:** Palantir Technologies Inc., **Annual Report on Form 10-K for the Fiscal Year Ended December 31, 2025**, filed with the U.S. Securities and Exchange Commission, February 2026, https://www.sec.gov/Archives/edgar/data/1321655/000132165526000011/pltr-20251231.htm. See Item 1, “Business,” and customer-revenue discussion.  
**URL(s):**
- https://www.sec.gov/Archives/edgar/data/1321655/000132165526000011/pltr-20251231.htm
- https://cpeisw.army.mil/2024/03/06/army-tactical-intelligence-targeting-access-node-titan-ground-station-prototype-award/
- https://cpeisw.army.mil/2026/09/01/army-announces-move-to-production-for-titan/

### SRC-026
**Used in:** Companion paper — COMP-08  
**Class:** Primary / official record  
**Citation as carried in paper:** Palantir Technologies, **Platforms**, including documentation for Gotham, Foundry, Apollo, AIP, and Ontology, accessed September 27, 2026, https://www.palantir.com/platforms/. For the company’s fuller description of platform functions, access controls, and deployment environments, see Palantir Technologies Inc., **2025 Form 10-K**, Item 1, https://www.sec.gov/Archives/edgar/data/1321655/000132165526000011/pltr-20251231.htm.  
**URL(s):**
- https://www.palantir.com/platforms/
- https://www.sec.gov/Archives/edgar/data/1321655/000132165526000011/pltr-20251231.htm

### SRC-027
**Used in:** Companion paper — COMP-10  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. Immigration and Customs Enforcement, **Privacy Impact Assessment Update for Investigative Case Management**, DHS/ICE/PIA-045(b), May 2020, https://www.dhs.gov/sites/default/files/publications/privacy-pia-ice-icm-may2020.pdf; U.S. House Committee on Oversight and Reform, **“The Surveillance Industry and the Department of Homeland Security,”** staff report, July 2022, https://oversightdemocrats.house.gov/sites/evo-subsites/democrats-oversight.house.gov/files/2022.07.13%20DHS%20Surveillance%20Report.pdf. The latter records congressional staff findings and should be read alongside the ICE privacy documentation.  
**URL(s):**
- https://www.dhs.gov/sites/default/files/publications/privacy-pia-ice-icm-may2020.pdf
- https://oversightdemocrats.house.gov/sites/evo-subsites/democrats-oversight.house.gov/files/2022.07.13%20DHS%20Surveillance%20Report.pdf

### SRC-028
**Used in:** Companion paper — COMP-11  
**Class:** Company / institutional primary  
**Citation as carried in paper:** Palantir Technologies, **“Palantir and the Israeli Ministry of Defense Enter Strategic Partnership,”** January 12, 2024, company announcement, https://x.com/PalantirTech/status/1745873372196512043; see also CTech, **“Palantir Supplying Israel With Technology to Help in War Effort,”** January 13, 2024, https://www.calcalistech.com/ctechnews/article/rymy7ret6. Public descriptions establish the partnership but do not disclose all system scope, data sources, or operating arrangements.  
**URL(s):**
- https://x.com/PalantirTech/status/1745873372196512043
- https://www.calcalistech.com/ctechnews/article/rymy7ret6

### SRC-029
**Used in:** Companion paper — COMP-15  
**Class:** Company / institutional primary  
**Citation as carried in paper:** Flock Safety, **Law Enforcement** product and policy materials, accessed September 27, 2026, https://www.flocksafety.com/law-enforcement. Access, retention, sharing, and audit practices vary by agency policy, contract, and jurisdiction.  
**URL(s):**
- https://www.flocksafety.com/law-enforcement

### SRC-030
**Used in:** Companion paper — COMP-19  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. Department of Defense, **“DoD Awards Joint Warfighting Cloud Capability Contracts,”** December 7, 2022, https://www.defense.gov/News/Releases/Release/Article/3239844/dod-awards-joint-warfighting-cloud-capability-contracts/. The award covered enterprise cloud capability across unclassified, secret, and top-secret classification levels; it did not announce a pooling of commercial customer data with classified workloads.  
**URL(s):**
- https://www.defense.gov/News/Releases/Release/Article/3239844/dod-awards-joint-warfighting-cloud-capability-contracts/

### SRC-031
**Used in:** Companion paper — COMP-20  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. Department of Homeland Security, **National Network of Fusion Centers Fact Sheet**, accessed September 27, 2026, https://www.dhs.gov/fusion-centers; U.S. Senate Permanent Subcommittee on Investigations, **Federal Support for and Involvement in State and Local Fusion Centers**, October 2012, https://www.hsgac.senate.gov/wp-content/uploads/imo/media/doc/PSI%20REPORT%20-%20Federal%20Support%20for%20and%20Involvement%20in%20State%20and%20Local%20Fusion%20Centers%20-%202012-10-03.pdf.  
**URL(s):**
- https://www.dhs.gov/fusion-centers
- https://www.hsgac.senate.gov/wp-content/uploads/imo/media/doc/PSI%20REPORT%20-%20Federal%20Support%20for%20and%20Involvement%20in%20State%20and%20Local%20Fusion%20Centers%20-%202012-10-03.pdf

### SRC-032
**Used in:** Companion paper — COMP-21  
**Class:** Primary / official record  
**Citation as carried in paper:** U.S. Department of State, **“Secretary of State Marco Rubio Remarks to the Press,”** March 28, 2025, https://www.state.gov/secretary-of-state-marco-rubio-remarks-to-the-press-3. Rubio stated that the United States may deny or revoke visas where it determines a visa holder’s activities are contrary to U.S. national interests or foreign policy. This statement addresses visa authority over noncitizens; it does not establish a general domestic enforcement authority over U.S. citizens.  
**URL(s):**
- https://www.state.gov/secretary-of-state-marco-rubio-remarks-to-the-press-3

### SRC-033
**Used in:** Companion paper — COMP-22  
**Class:** Primary / official record  
**Citation as carried in paper:** *Khalil v. Joyce*, No. 25-CV-1935 (JMF), Opinion and Order, U.S. District Court for the Southern District of New York, March 19, 2025, https://www.nysd.uscourts.gov/sites/default/files/2025-03/25cv1935%20%5B78%5D%20Opinion%20and%20Order%203.19.2025.pdf. The court recounted that Khalil, a lawful permanent resident, alleged retaliation for participation in Gaza-related campus protests, while the government invoked the Secretary of State’s foreign-policy determination under 8 U.S.C. § 1227(a)(4)(C)(i). The order transferred the habeas action on jurisdictional grounds and did not adjudicate the merits of those contested allegations.  
**URL(s):**
- https://www.nysd.uscourts.gov/sites/default/files/2025-03/25cv1935%20%5B78%5D%20Opinion%20and%20Order%203.19.2025.pdf

### SRC-034
**Used in:** Companion paper — COMP-23  
**Class:** Secondary journalism  
**Citation as carried in paper:** Dell Cameron and Yulia Almazova, **“Leak Exposes Members of Peter Thiel’s Secretive ‘Dialog’ Society,”** *WIRED*, June 16, 2026, https://www.wired.com/story/leak-exposes-members-of-peter-thiels-secretive-dialog-society/. The article reports that *WIRED* independently verified internal records and a 2026 registration list naming 222 registrants. The reporting is used only for descriptions of reported membership and institutional proximity; membership or association does not establish operational coordination or control.  
**URL(s):**
- https://www.wired.com/story/leak-exposes-members-of-peter-thiels-secretive-dialog-society/

### SRC-035
**Used in:** Companion paper — COMP-24  
**Class:** Company / institutional primary  
**Citation as carried in paper:** Palantir Technologies, **Company History and Leadership**, accessed September 27, 2026, https://www.palantir.com/; 8VC, **Team: Joe Lonsdale**, accessed September 27, 2026, https://www.8vc.com/team/joe-lonsdale; Founders Fund, **Peter Thiel**, accessed September 27, 2026, https://foundersfund.com/team/peter-thiel/. These sources document professional and investment relationships, not a unified command structure or a common operational agenda.  
**URL(s):**
- https://www.palantir.com/
- https://www.8vc.com/team/joe-lonsdale
- https://foundersfund.com/team/peter-thiel/

### SRC-036
**Used in:** Companion paper — COMP-25  
**Class:** Primary / official record  
**Citation as carried in paper:** Executive Order 14188, **Additional Measures To Combat Anti-Semitism**, January 29, 2025, GovInfo, https://www.govinfo.gov/app/details/DCPD-202500196; U.S. Department of Justice, **“Justice Department Announces Formation of Task Force to Combat Anti-Semitism,”** February 3, 2025, updated July 22, 2026, https://www.justice.gov/opa/pr/justice-department-announces-formation-task-force-combat-anti-semitism. The order directs agencies to identify available civil and criminal authorities and separately addresses immigration consequences for certain noncitizens; it does not make protected criticism of Israel by U.S. citizens unlawful.  
**URL(s):**
- https://www.govinfo.gov/app/details/DCPD-202500196
- https://www.justice.gov/opa/pr/justice-department-announces-formation-task-force-combat-anti-semitism

### SRC-037
**Used in:** Companion paper — COMP-26  
**Class:** Secondary journalism  
**Citation as carried in paper:** Mike Allen, **“Scoop: Dialog, a secretive forum, plans D.C.-area campus,”** Axios, August 7, 2025, updated June 2026, https://www.axios.com/2025/08/07/dialog-secret-network-thiel-hoffman. Axios identifies Peter Thiel and Auren Hoffman as Dialog’s founders and lists Senator Cory Booker among reported participants. Public reporting reviewed here does not establish that Booker is a founder or that he receives compensation from Dialog.  
**URL(s):**
- https://www.axios.com/2025/08/07/dialog-secret-network-thiel-hoffman

### SRC-038
**Used in:** Companion paper — COMP-27  
**Class:** Secondary journalism  
**Citation as carried in paper:** Dell Cameron, Dhruv Mehrotra, and Yulia Almazova, **“How the Peter Thiel-Linked Dialog Club Secretly Ranks Its Members,”** *WIRED*, June 18, 2026, https://www.wired.com/story/how-peter-thiels-private-dialog-club-secretly-ranks-its-members/. *WIRED* reports that Dialog uses internal rankings tied to wealth and fame, tracks member relationships, and uses those data in matching and fee decisions; Dialog describes itself as nonpartisan and nonpolitical.  
**URL(s):**
- https://www.wired.com/story/how-peter-thiels-private-dialog-club-secretly-ranks-its-members/

### SRC-039
**Used in:** Companion paper — COMP-28  
**Class:** Secondary journalism  
**Citation as carried in paper:** Johana Bhuiyan, **“Key Trump allies and Musk on leaked list for secretive Peter Thiel retreat,”** *The Guardian*, June 20, 2026, updated June 22, 2026, https://www.theguardian.com/technology/2026/jun/20/trump-elon-musk-peter-thiel-retreat. *The Guardian* reported that it independently verified the leaked directory through an Internet Archive snapshot. The article stresses that the dates, capacity, and degree of involvement of many listed individuals were unclear and includes statements from several people distancing themselves from Dialog or describing limited past participation.  
**URL(s):**
- https://www.theguardian.com/technology/2026/jun/20/trump-elon-musk-peter-thiel-retreat

### SRC-040
**Used in:** Companion paper — COMP-29  
**Class:** Secondary journalism  
**Citation as carried in paper:** Dell Cameron and Yulia Almazova, **“The Pentagon Is Looking Into the Dialog Data Exposure for Unmasking National Security Officials,”** *WIRED*, June 2026, https://www.wired.com/story/the-pentagon-is-looking-into-the-dialog-data-exposure-for-unmasking-national-security-officials. *WIRED* reported that exposed Dialog records included sensitive information tied to current and former U.S. and allied military and intelligence personnel and that the Pentagon was reviewing the exposure. This establishes a data-security consequence of the leak, not evidence that Dialog itself is an intelligence operation.  
**URL(s):**
- https://www.wired.com/story/the-pentagon-is-looking-into-the-dialog-data-exposure-for-unmasking-national-security-officials

## Register QA / Open Source-Capture Items
Current source-capture status after the September 30 paper reconciliation:
- **SRC-009** — still requires a clean direct-source decision or removal if not used in the final publication package.
- **SRC-010** — direct Microsoft Annual Report / SEC URLs are now carried in the current flagship paper source notes; source-capture issue resolved for publication use.
- **SRC-018** — direct Social Security Administration URLs are now carried in the current flagship paper source notes; source-capture issue resolved for publication use.
- **SRC-013** — current paper source note uses the FAA FAALC single-source justification posted **April 9, 2026**; retain that date unless later primary verification changes it.

## Next Backend Step
Build the **Master Claim Ledger** against these stable source IDs, with fields for: claim, paper/section, evidence status, what the source proves, what it does not prove, actor/project, date, money/data/authority involved, unresolved question, and verification status.


---

## 2026 SWEEP ADDENDUM — 2026-09-28

These sources were added after the targeted 2025–2026 national sweep. Existing Dialog reporting remains under **SRC-034 / SRC-037 / SRC-038 / SRC-039 / SRC-040** rather than being duplicated.

| ID | Source | Class | URL | Supports |
|---|---|---|---|---|
| SRC-041 | OpenAI, “Announcing The Stargate Project,” Jan. 21, 2025 | Company / institutional primary | https://openai.com/index/announcing-the-stargate-project/ | Stargate company framing; $500B target; $100B initial deployment; initial equity funders; announced roles. |
| SRC-042 | SoftBank Group, “Announcing The Stargate Project,” Jan. 22, 2025 | Company / institutional primary | https://group.softbank/en/news/press/20250122 | Confirms Stargate announcement, initial funders, SoftBank financial responsibility, OpenAI operational responsibility. |
| SRC-043 | OpenAI, “Stargate Advances with Partnership with Oracle,” July 22, 2025 | Company / institutional primary | https://openai.com/index/stargate-advances-with-partnership-with-oracle/ | 4.5-GW additional U.S. development-capacity announcement; not operating load. |
| SRC-044 | OpenAI, “OpenAI, Oracle, and SoftBank Expand Stargate With Five New AI Data Center Sites,” Sept. 23, 2025 | Company / institutional primary | https://openai.com/index/five-new-stargate-sites/ | Five additional U.S. sites; nearly 7 GW planned capacity; network expansion structure. |
| SRC-045 | OpenAI, “Building the Compute Infrastructure for the Intelligence Age,” Apr. 29, 2026 | Company / institutional primary | https://openai.com/index/building-the-compute-infrastructure-for-the-intelligence-age/ | Abilene workload activity; broader Stargate capacity claims; company-reported expansion. |
| SRC-046 | OpenAI, “Stargate Community,” Jan. 20, 2026 | Company / institutional primary | https://openai.com/index/stargate-community/ | Named Stargate community locations; Abilene operating reference; community framing. |
| SRC-047 | Oracle, “AI Data Centers,” accessed Sept. 2026 | Company / institutional primary | https://www.oracle.com/data-centers/ | Project Jupiter fuel-cell claim; Oracle Abilene progress representations. |
| SRC-048 | Oracle, “Oracle Is Set to Power On New Data Center in Michigan,” Dec. 18, 2025 | Company / institutional primary | https://www.oracle.com/news/announcement/blog/oracle-is-set-to-power-on-new-data-center-in-michigan-2025-1018/ | Project Jupiter construction schedule; DTE service reference; local investment claims. |
| SRC-049 | Oracle, “AI Data Centers: Investing in Communities, Powering the Future,” May 2026 | Company / institutional primary | https://www.oracle.com/anz/data-centers/ | Saline Township construction participation by OpenAI, Oracle, Related Digital, Blackstone, Walbridge. |
| SRC-050 | U.S. Department of Energy, “Energy Department Announces Partnership to Ensure Affordable Energy and Power America’s AI,” Feb. 25, 2026 | Primary / official record | https://www.energy.gov/articles/energy-department-announces-partnership-ensure-affordable-energy-and-power-americas-ai | DOE/Commerce/SoftBank/AEP Ohio Portsmouth partnership; federal-site use. |
| SRC-051 | U.S. Department of Energy, “Partnership Ensures Affordable Energy, Powers AI Future at Portsmouth Site,” Mar. 24, 2026 | Primary / official record | https://www.energy.gov/em/articles/partnership-ensures-affordable-energy-powers-future-portsmouth-site | Portsmouth site context; federal-land and infrastructure relationship. |
| SRC-052 | AEP Ohio, “AEP Ohio Partners to Bring $4.2B in New Electric Infrastructure in Appalachian Ohio Without Raising Customer Rates,” Mar. 20, 2026 | Company / institutional primary | https://www.aepohio.com/company/news/view?releaseID=10824 | SB Energy as payer of stated $4.2B infrastructure plan; utility ratepayer-protection representation. |
| SRC-053 | AEP Ohio, “AEP Ohio Announces Open Houses for Customer-Funded Power Grid Upgrades,” May 6, 2026 | Company / institutional primary | https://www.aepohio.com/company/news/view?releaseID=11922 | Pike/Jackson/Gallia grid upgrades connected to planned Portsmouth campus. |
| SRC-054 | AEP Ohio, “AEP Ohio Updates PUCO on Data Center Load,” Feb. 13, 2026 | Company / institutional primary | https://www.aepohio.com/company/news/view?releaseID=10753 | Large-load tariff framework; screening and cost-allocation evidence. |
| SRC-055 | Meta, “Teachers and Local Businesses Win as Meta Expands Louisiana Data Center,” July 13, 2026 | Company / institutional primary | https://about.fb.com/news/2026/07/teachers-local-businesses-win-as-meta-expands-louisiana-data-center/ | Richland Parish expansion to stated 5-GW compute capacity; not current electric load. |
| SRC-056 | Entergy Louisiana, “Entergy Louisiana Receives LPSC Approval for Major Infrastructure Investments to Support Meta’s Data Center and Improve Reliability,” Aug. 20, 2025 | Company / institutional primary | https://www.entergy.com/news/entergy-louisiana-receives-lpsc-approval-for-major-infrastructure-investments-to-support-metas-data-center-and-improve-reliability | Regulatory approval for infrastructure investments associated with Meta campus. |
| SRC-057 | Entergy Louisiana, “Entergy Louisiana Announces a New Agreement With Meta,” Mar. 27, 2026 | Company / institutional primary | https://www.entergy.com/news/entergy-louisiana-announces-a-new-agreement-with-meta-that-will-deliver-an-additional-2b-in-customer-savings | Utility assertion that Meta will cover new-infrastructure costs; stated customer-savings rationale. |
| SRC-058 | Meta, “Meta Announces Nuclear Energy Projects, Unlocking Up to 6.6 GW,” Jan. 9, 2026 | Company / institutional primary | https://about.fb.com/news/2026/01/meta-nuclear-energy-projects-power-american-ai-leadership/ | Up-to-6.6-GW portfolio claim; requires disaggregation by capacity type and timing. |
| SRC-059 | White House, “Accelerating Federal Permitting of Data Center Infrastructure,” July 23, 2025 | Primary / official record | https://www.whitehouse.gov/presidential-actions/2025/07/accelerating-federal-permitting-of-data-center-infrastructure/ | Federal permitting acceleration for qualifying data centers and related energy/transmission infrastructure. |
| SRC-060 | Box Elder County, Utah, “Box Elder Stratos Project Information,” June 10, 2026 | Primary / official record | https://www.boxeldercountyut.gov/641/Stratos-Project | Stratos project-area governance; environmental review, water, tax-revenue and public-information categories. |
| SRC-061 | Salt Lake Tribune, “O’Leary: Box Elder County Data Center Is ‘Full Steam Ahead’…,” July 29, 2026 | Secondary journalism | https://www.sltrib.com/news/2026/07/29/oleary-box-elder-county-data/ | O’Leary promoter/developer role and project-status claims. |
| SRC-062 | ABC4 Utah, “Kevin O’Leary Discusses Box Elder County Data Center,” June 2, 2026 | Secondary journalism | https://www.abc4.com/news/politics/inside-utah-politics/kevin-oleary-stratos-project-interview/ | O’Leary descriptions of phased construction and anticipated role. |
| SRC-063 | Fortune, “Shark Tank’s Kevin O’Leary Is Building a $100 Billion Data Center in Utah,” May 11, 2026 | Secondary journalism | https://fortune.com/2026/05/11/shark-tank-kevin-oleary-millionaire-utah-data-center-american-politics-protests-ai-tech/ | Stratos acreage, scale, local approval context and controversy. |
| SRC-064 | Reuters, “New York Becomes the First State to Impose a Data Center Moratorium,” July 14, 2026 | Secondary journalism | https://www.reuters.com/world/new-york-becomes-first-state-impose-data-center-moratorium-2026-07-14/ | New York reported pause; direct state text still required before definitive legal wording. |
| SRC-065 | Brookings, “Data Center Moratoriums Are Not a Substitute for Oversight,” Aug. 11, 2026 | Secondary / policy analysis | https://www.brookings.edu/articles/data-center-moratoriums-are-not-a-substitute-for-oversight/ | Context for state/local restrictions; not substitute for jurisdiction-specific legal records. |
| SRC-066 | U.S. Department of Energy, “Powering America’s AI Future—Data Center Resource Hub,” June 16, 2026 | Primary / official record | https://www.energy.gov/powering-americas-ai-future-data-center-resource-hub | Federal framing of AI data-center infrastructure and energy policy. |
| SRC-067 | U.S. Department of Energy, “Advantages and Challenges of Nuclear-Powered Data Centers,” Apr. 8, 2025 | Primary / official record | https://www.energy.gov/ne/articles/advantages-and-challenges-nuclear-powered-data-centers | Nuclear timing/cost constraints; counterweight to near-term nuclear claims. |

---

## 2026-09-30 PALANTIR / PLATFORM SOURCE ADDENDUM

These source IDs extend the existing register without renumbering prior sources.

| ID | Source | Class | URL / record | Supports |
|---|---|---|---|---|
| SRC-068 | U.S. Department of Defense, Contracts for May 29, 2024 and May 21, 2025 — Maven Smart System awards to Palantir | Primary / official record | https://www.defense.gov/News/Contracts/Contract/Article/3790490/ ; https://www.defense.gov/News/Contracts/Contract/Article/4194643/ | $480M Maven contract; $795M 2025 modification; procurement scale through 2029. |
| SRC-069 | Deputy Secretary of Defense Steve Feinberg March 9, 2026 Maven directive, as reported by Reuters and DefenseScoop | Secondary reporting on internal primary memo | Reuters, Mar. 20, 2026; DefenseScoop, Apr. 3, 2026 | Ordered transition of Maven Smart System into a formal program of record by end of FY2026. |
| SRC-070 | U.S. Army, “U.S. Army Awards Enterprise Service Agreement to Enhance Military Readiness and Drive Operational Efficiency,” July 31, 2025 | Primary / official record | https://www.army.mil/article/287506/u_s_army_awards_enterprise_service_agreement_to_enhance_military_readiness_and_drive_operational_efficiency | Consolidates 75 Palantir contracts; up to ten years; $10B maximum potential value, not obligated spend. |
| SRC-071 | U.S. Army, “Army and Industry Align on Common Data Baseline, as Next Generation Command and Control Moves from Prototyping to Delivery,” June 22, 2026 | Primary / official record | https://www.army.mil/article/293409/army_and_industry_align_on_common_data_baseline_as_next_generation_command_and_control_moves_from_prototyping_to_delivery | Anduril-led common data baseline; edge-to-cloud data mesh uses Anduril Lattice and Palantir Foundry. |
| SRC-072 | U.S. Immigration and Customs Enforcement, Limited Sources Justification for Contract 70CTD022FR0000170, Apr. 17, 2025 | Primary / official procurement record | Contract / justification record; federal procurement action signed Apr. 11, 2025 | ImmigrationOS mission areas: Targeting and Enforcement Prioritization; Self-Deportation Tracking; Immigration Lifecycle Process. |
| SRC-073 | Amnesty International, “Palantir: Response from Palantir to Amnesty International,” Aug. 21, 2025, reproducing Palantir response of July 24, 2025 | Attributed company response via NGO publication | https://www.amnesty.org/en/documents/amr51/0211/2025/en/ | Palantir denial that it provides the State Department Catch and Revoke operating system; separate confirmation of expanded ICE-HSI ICM mission areas. |
| SRC-074 | Palantir Technologies Inc., Form 10-K for FY ended Dec. 31, 2024, filed 2025 | Primary / official SEC filing | https://www.sec.gov/Archives/edgar/data/1321655/000132165525000059/fy2024palantirarsa.htm | Palantir disclosure that it agreed to supply technology to Israel “to assist in the ongoing war.” |

### Source-boundary note
SRC-068 through SRC-074 materially strengthen the documented Palantir footprint. They do **not** by themselves establish a provision-specific Palantir award, executive-agent designation, implementation role, universal data access, or direct operational role in §219, §1217, or §622.



---

## 2026-10-02 POLITICAL-FINANCE SOURCE ADDENDUM

| ID | Source | Class | URL / provenance | Supports |
|---|---|---|---|---|
| SRC-075 | Federal Election Commission, **American Israel Public Affairs Committee Political Action Committee**, committee C00797670; registered Dec. 15, 2021 | Primary / official record | https://www.fec.gov/data/committee/C00797670/ | AIPAC PAC identity, registration, federal committee status and disbursement records. Does not by itself establish the 26-of-38 audit result; that result is the product of the preserved Pass 2A row-level review. |
| SRC-076 | **Pass 2 — AIPAC PAC and United Democracy Project Support in Major U.S. Data-Center Jurisdictions, 2020–2026** | Research artifact built from FEC records | User-supplied / project research artifact | Defined federal-official universe; AIPAC PAC direct-contribution results; refund qualifications; no relevant UDP IE result in reviewed universe; historical/current distinctions. Must remain separate from project-facilitation findings. |
| SRC-077 | **Pass 1 — Data-center project / facilitation evidence register** | Research artifact built from primary / secondary records | User-supplied / project research artifact | Closed project universe and documented facilitating actors/actions; establishes that most project-specific facilitation found in the pass occurred at state, local, development-authority, permitting, and utility-regulatory levels rather than through the federal jurisdictional officials carried in Pass 2A. |
| SRC-078 | Louisiana Ethics Administration Program, Jeff Landry candidate filings, 2025 annual report LA-132570 / report 26002716 | Primary / official record | https://ethics.la.gov/CampaignFinanceSearch/ViewEFiler.aspx?FilerID=CAN991431 | Recipient-side filing location for the 2025 Landry report. Pass 2B review recorded two Meta Platforms Inc. $12,000 contributions dated Oct. 27, 2025; no offset/refund located in reviewed schedules. |
| SRC-079 | Georgia Government Transparency and Campaign Finance Commission, Georgians First Leadership Committee registration, filer NC2022000002 | Primary / official record | https://media.ethics.ga.gov/Search/Campaign/Campaign_Name.aspx?FilerID=NC2022000002&NameID=35069&Type=committee | Committee is registered as a Political Action Committee; Brian Kemp listed as chairperson. |
| SRC-080 | Georgia Government Transparency and Campaign Finance Commission, Georgians First Leadership Committee contribution report | Primary / official record | https://media.ethics.ga.gov/search/Campaign/Campaign_ByContributions_RFR.aspx?CDRID=163592&FilerID=NC2022000002&Name=Georgians+First+Leadership+Committee&NameID=35069&Report=January+31st+-+Election+Year&Year=2022 | Georgia Power contributions: $18,000 on Sept. 17, 2021 and $20,000 on Dec. 8, 2021. |
| SRC-081 | Commonwealth of Pennsylvania, Governor's Office, **ICYMI: Governor Shapiro and DEP Secretary Shirley Highlight Administration's Work to Speed Up Permitting... at Future Amazon Data Center Site in Bucks County**, Aug. 8, 2025 | Primary / official record | https://www.pa.gov/governor/newsroom/2025-press-releases/icymi--gov-shapiro---sec-shirley-highlight-admin-s-work-to-speed | Documents Shapiro/DEP appearance with NorthPoint executives at Keystone Trade Center; administration states it worked with NorthPoint to coordinate and accelerate permit processing at the future AWS site. This is project-policy / permitting evidence, not campaign-finance evidence. |
| SRC-082 | Pennsylvania Department of State campaign-finance report page, Friends of Josh Shapiro report 82986 | Primary / official record, incomplete extraction | https://www.campaignfinanceonline.pa.gov/Pages/ShowReport.aspx?ReportID=82986&isStatement=0&is24Hour=0 | Confirms relevant Shapiro campaign report exists; accessible result did not expose the itemized NorthPoint transaction row, so the reported $100,000 contribution remains provisional at transaction level. |
| SRC-083 | Spotlight PA reporting identifying NorthPoint Development as a reported $100,000 donor to Shapiro for Pennsylvania | Secondary journalism | https://www.spotlightpa.org/news/2026/04/garrity-shapiro-governor-election-2026-fundraising-elections/ | Secondary support for NorthPoint → Shapiro contribution lead; legal donor name, date, amendment/refund status and itemized primary row remain unresolved. |
| SRC-084 | Transparency USA compilation of Ann Wheeler campaign-finance data, including reported IBEW Local 26 support | Secondary compilation | https://www.transparencyusa.org/va/candidate/ann-wheeler?cycle=2023-election-cycle&filer=wheeler-for-pwc-cc-18-00478-candidate | Supports IBEW Local 26 → Ann Wheeler $55,000 2023-cycle lead as a secondary compilation; recipient-side primary transaction normalization remains pending. |
| SRC-085 | Data Center Coalition public policy materials; NCSL state data-center incentive overview | Industry primary + institutional secondary | https://www.datacentercoalition.org/ ; https://www.ncsl.org/fiscal/subsidizing-servers-how-states-are-competing-to-attract-data-centers | Sector-policy / trade-association context, including advocacy around energy access and competitive business/tax policy; does not establish project-specific lobbying or member-by-member attribution. |
| SRC-086 | Perplexity Pass 2C continuation outputs, Oct. 2, 2026 | Research artifact / discovery layer | User-supplied `Pasted text(20261002-163413).txt` and `Pasted text(20261002-164052).txt` | Preserves the closed-universe crosswalk, database-access limitations, transaction-status grades, and newly surfaced Pennsylvania permitting record. Not a substitute for the underlying primary filings. |

### Source-use boundary

For political-finance claims, prefer the underlying primary record (FEC, state campaign-finance system, municipal filing, lobbying filing, utility docket) over Pass 2 artifacts. Pass 1 / 2A / 2B / 2C artifacts are provenance and synthesis layers. A missing itemized schedule, blocked portal, unfiled report, or inaccessible municipal database is **not** evidence that no relationship exists.


## 2026-10-14 FINAL PUBLICATION RECONCILIATION — SOURCE ADDITIONS

*Delta only. Sources already carried in the final Oct. 12–13 papers' footnotes; no new research. Nothing above is changed.*

| ID | Source | Class | Used in | Paper ref(s) |
|---|---|---|---|---|
| SRC-087 | U.S. Senate, Roll Call Vote 195, July 14, 2026, https://www.senate.gov/legislative/LIS/roll_call_votes/vote1192/vote_119_2_00195.htm. Cloture on the motion to proceed to S. 4784 rejected 50–46; a motion to reconsider was entered. | Primary / official legislative record | CLM-103, CLM-104, TL 2026-07-14 | IOP fn [2] |
| SRC-088 | U.S. Army Public Affairs, “Army Launches Detachment 201: Executive Innovation Corps to Drive Tech Transformation,” June 13, 2025, https://www.army.mil/article/286317; U.S. Army Reserve, “Army Reserve Soldiers front and center of Army’s new Detachment 201: Executive Innovation Corps,” June 13, 2025, https://www.usar.army.mil/News/Article/4216167/ | Primary / official agency announcement | CLM-105, REL-074, TL 2025-06-13 | IOP fn [20]; DCD fn [37] (army.mil only) |
| SRC-089 | Federal procurement record of a Palantir contract action of $29,898,236 signed April 11, 2025, as cited in the Companion paper (companion to SRC-072). | Official procurement record, as carried in paper | CLM-106, REL-075, TL 2025-04-11 | IOP fn [22] |

*SRC-089 boundary:* the paper's footnote states the amount and signing date but carries no record locator. The locator is logged in file 07 as a citation-completion item, not a research question.
