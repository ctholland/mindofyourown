# DATA CENTER DISCONNECT — RELATIONSHIP LEDGER

**Project:** The Data Center Disconnect and the Dystopian Debacle / The Architecture of Interoperable Power  
**Author:** C.T. Holland / Mind Of Your Own®  
**Backend location:** `04_EVIDENCE_BACKEND/04_RELATIONSHIP_LEDGER.md`  
**Evidence controls:** `01_MASTER_SOURCE_REGISTER.md`, `02_MASTER_CLAIM_LEDGER.md`, `03_MASTER_TIMELINE.md`  
**Status:** Working edge map. Every row is a bounded relationship, not a theory of total coordination.  

## Governing Rule

**ACTOR A → MECHANISM → ACTOR B.**  

A documented relationship is not the same as control. Proximity is not coordination. A common vendor is not a common database. A capability is not proof of use. A contract is not proof of access beyond its scope. A private network is not proof of a unified political bloc. Every edge below states both **what the relationship proves** and **what it does not prove**.

## Relationship Ledger

| Edge ID | Actor A | Mechanism | Actor B | Relationship type | Source ID(s) | What the edge proves | What it does NOT prove | Strength |
|---|---|---|---|---|---|---|---|---|
| REL-001 | U.S. House of Representatives | Legislation / proposed defense-technology initiative | U.S. Department of Defense / designated executive agent | Authority / policy | SRC-019; SRC-021 | Creates a proposed institutional mechanism for U.S.–Israel defense-technology cooperation and possible incorporation of jointly developed or Israeli-origin technologies into U.S. systems/programs of record. | Does not establish enacted law, automatic interoperability, civilian-data access, or Israeli control of U.S. systems. | Strong / primary |
| REL-002 | U.S. Senate | Legislation / FUTURES Act provision | U.S. Department of Defense / U.S.–Israel defense-technology cooperation | Authority / policy | SRC-020; SRC-022 | Documents a related Senate legislative pathway for bilateral research, development, testing, evaluation, coordination, and industrial cooperation. | Does not prove final enactment or identical language to the House bill. | Strong / primary |
| REL-003 | U.S. Senate Intelligence Committee / S. 4615 §622 | Proposed intelligence-sharing enhancement | Israel | Authority / intelligence sharing | SRC-023; SRC-024 | Documents a proposed expansion/enhancement of intelligence sharing with Israel in specified domains. | Does not establish general access to U.S. civilian databases, commercial data, or domestic political-activity records. | Strong / primary |
| REL-004 | President / DNI / Secretary of Defense | Authority under proposed §622 | Israel | Authority / intelligence | SRC-023 | Specifies the U.S. executive actors through whom covered intelligence sharing would be expanded/enhanced. | Does not identify every technical system, data category, liaison channel, or vendor involved. | Strong / primary |
| REL-005 | Palantir Technologies | Strategic partnership / technology support | Israel Ministry of Defense | Commercial / defense capability | SRC-028 | Documents a direct Palantir–Israeli defense relationship in support of war-related missions. | Does not prove Palantir operates every U.S.–Israel defense/intelligence initiative or links U.S. civilian data to Israel. | Strong |
| REL-006 | Palantir Technologies | Government contracts / platform deployment | U.S. government customers | Commercial / platform | SRC-025 | Documents substantial U.S. government business and Palantir’s role as a data-integration/decision-support vendor. | Does not prove cross-customer data sharing or sovereign decision authority. | Strong |
| REL-007 | Palantir Technologies | TITAN prototype and production work | U.S. Army | Commercial / defense procurement | SRC-025 | Documents a specific defense procurement relationship progressing from prototype to production. | Does not establish all Army data access or Palantir control over military decisions. | Strong |
| REL-008 | Palantir Technologies | Investigative Case Management / operational systems | U.S. Immigration and Customs Enforcement | Commercial / homeland security | SRC-027 | Documents Palantir systems inside immigration/homeland-security investigative workflows. | Does not prove use beyond the specific program authorities or a connection to Israeli systems. | Strong |
| REL-009 | Palantir Foundry / integration services | Federal Aviation Administration Logistics Center | Commercial / data integration | SRC-013 | Documents a federal requirement for integrating, transforming, and analyzing disparate operational data for AI-enabled decision support. | Does not establish access to all FAA or federal data. | Strong |
| REL-010 | Google Public Sector | Cloud infrastructure / accredited hosting pathway | Palantir FedStart | Commercial / cloud / compliance | SRC-011; SRC-012 | Documents a layered relationship combining Google Cloud infrastructure with Palantir’s federal deployment offering. | Does not establish unrestricted access by either company to government customer data. | Strong |
| REL-011 | Palantir FedStart | Compliance/deployment pathway | Federal agencies / public-sector software customers | Commercial / procurement enablement | SRC-012 | Shows how preconfigured compliance/deployment infrastructure can lower friction for federal software adoption. | Does not eliminate agency-specific procurement, legal, security, or mission controls. | Strong / first-party |
| REL-012 | AWS / Google / Microsoft / Oracle | JWCC contracts | U.S. Department of Defense | Commercial cloud / defense | SRC-030 | Documents commercial cloud providers supporting DoD workloads across multiple classification levels. | Does not mean ordinary commercial workloads are pooled with classified government data. | Strong |
| REL-013 | Commercial cloud providers | Accredited cloud environments | Federal agencies / government systems | Infrastructure / operational dependency | SRC-011; SRC-030 | Establishes that public functions can rely on private compute/storage infrastructure under government security frameworks. | Does not imply provider ownership of agency authority or universal visibility into workload contents. | Strong |
| REL-014 | NIST credential service provider model | Federation / assertions | Separately administered relying parties | Identity / standards | SRC-015 | Documents a technical model for identity attributes/authentication to be recognized across separately administered systems. | Does not create a universal national identity database. | Strong / primary |
| REL-015 | Social Security Administration / SSN | Administrative identifier expansion over time | Public and private institutions | Identity / historical | SRC-018 | Shows that a narrower identifier can acquire broader institutional use over time. | Does not establish technical equivalence to modern federated digital identity systems. | Historical |
| REL-016 | Federal Reserve / FedNow | Instant-payment infrastructure | Banks / financial institutions | Financial rails | SRC-017 | Documents a real-time payment rail distinct from a CBDC. | Does not establish a CBDC, programmable central-bank control, or unified financial-control grid. | Strong / primary |
| REL-017 | Flock Safety | ALPR network / vehicle detection search | Participating law-enforcement customers | Location / surveillance capability | SRC-029 | Documents searchable vehicle-location capability across participating sources subject to policy/permissions. | Does not establish universal nationwide visibility or unrestricted access. | Moderate / first-party |
| REL-018 | Federal agencies | Access arrangements | Other federal / state-local / private facial-recognition systems | Cross-institution data access | SRC-016 | GAO documents that agencies accessed systems owned by other entities. | Does not establish universal facial recognition or unrestricted access by all agencies. | Strong / primary |
| REL-019 | Fusion centers | Information-sharing mechanisms | Federal / state / local / tribal / territorial / private-sector partners | Information sharing / homeland security | SRC-031 | Documents an institutional model designed to move information across organizational boundaries. | Does not prove unlawful sharing or a total surveillance state. | Strong / primary |
| REL-020 | Executive Order 14188 / federal agencies | Coordinated identification/use of authorities | DOJ / Education / State / DHS / other agencies | Administrative / policy | SRC-036 | Documents a multi-agency framework addressing antisemitism through existing authorities. | Does not make protected criticism of Israel by U.S. citizens unlawful. | Strong / primary |
| REL-021 | Department of Justice | Multi-agency antisemitism task force | Schools / universities / participating agencies | Administrative / enforcement coordination | SRC-036 | Documents coordinated federal attention to antisemitism in education-related environments. | Does not establish a national-security pipeline for political dissent. | Strong / primary |
| REL-022 | Secretary of State / State Department | Visa denial/revocation authority | Certain noncitizens | Immigration / administrative authority | SRC-032 | Documents the administration’s articulated use of foreign-policy/visa authority over noncitizens. | Does not create equivalent immigration authority over U.S. citizens. | Strong / political statement |
| REL-023 | Secretary of State foreign-policy determination | Statutory removal ground invoked by government | Mahmoud Khalil / LPR immigration proceeding | Immigration / legal authority | SRC-033 | Documents a concrete case where protest-related allegations, foreign policy, and immigration authority intersected. | Does not prove the allegations or validate the government’s position on the merits. | Strong / court record |
| REL-024 | Dialog | Private invitation-based network | Technology / finance / government / defense / media / foreign officials | Elite network / access | SRC-034; SRC-039 | Documents a cross-sector environment in which powerful actors from different institutions and parties are connected. | Does not establish equal involvement, shared ideology, coordination, or command. | Strong secondary reporting |
| REL-025 | Peter Thiel + Auren Hoffman | Founding / institutional leadership | Dialog | Elite network / institutional | SRC-037; SRC-039 | Public reporting identifies Thiel and Hoffman as founders/co-founders of Dialog. | Does not prove personal control over every event, participant, or outcome. | Strong secondary reporting |
| REL-026 | Dialog | Ranking / relationship tracking / algorithmic introductions / pricing | Dialog participants | Data / classification / access | SRC-038 | Documents internal use of participant data, classifications, relationship management, and algorithmic recommendations to shape access and introductions. | Does not establish illegality or equivalence to government surveillance systems. | Strong secondary reporting |
| REL-027 | Dialog leaked data | Data exposure | Current/former military and intelligence personnel | Data security / national security | SRC-040 | Documents that the leak exposed sensitive information associated with national-security personnel and triggered Pentagon review. | Does not prove Dialog is an intelligence operation or that exposed information was weaponized. | Strong secondary reporting |
| REL-028 | Cory Booker | Reported attendance/association in Dialog records | Dialog | Political / elite network proximity | SRC-037; SRC-039 | Documents reported association/listing and subsequent distancing by Booker’s spokesperson. | Does not establish cofounder status, payment, active membership, or policy coordination. | Qualified |
| REL-029 | Ted Cruz / other elected officials | Reported attendance/association in Dialog records | Dialog | Political / elite network proximity | SRC-039 | Documents cross-partisan elected-official proximity to the same private network. | Does not establish a 'uniparty,' shared agenda, or equivalent degree of involvement. | Qualified |
| REL-030 | Serving Trump administration officials | Reported Dialog directory association | Dialog | Government / elite network proximity | SRC-039 | Documents reported overlap between current public officials and a private cross-sector network. | Does not establish improper conduct, undisclosed compensation, or policy quid pro quo. | Qualified |
| REL-031 | Foreign officials / former officials | Reported Dialog directory association | Dialog | International / elite network proximity | SRC-039 | Documents transnational participation/association within the network. | Does not prove foreign influence over U.S. policy or coordinated agenda-setting. | Qualified |
| REL-032 | Peter Thiel | Co-founder / investor | Palantir Technologies | Ownership / founder relationship | SRC-025; SRC-035 | Documents Thiel’s foundational relationship to Palantir. | Does not establish operational control over every current Palantir decision or government contract. | Strong |
| REL-033 | Joe Lonsdale | Palantir co-founder / 8VC co-founder | Palantir / 8VC | Founder / investment network | SRC-035 | Documents institutional links across data-platform and venture-capital environments. | Does not establish shared command over portfolio companies or policy actors. | Strong |
| REL-034 | 8VC / Founders Fund / defense-tech investors | Venture capital | Defense / government-technology companies | Capital / market formation | SRC-035 | Documents a capital pathway supporting companies that sell into government/defense markets. | Does not establish procurement capture, illicit influence, or common political intent. | Moderate |
| REL-035 | Data-center developers / hyperscalers | Large-load demand | Utilities / grid operators | Physical infrastructure / energy | SRC-002; SRC-003; SRC-004; SRC-008 | Documents how large compute demand creates grid-planning, interconnection, and cost-allocation consequences. | Does not establish that every grid upgrade is solely caused by data centers. | Strong |
| REL-036 | Utilities / grid operators | Interconnection / transmission planning | Data-center projects | Physical infrastructure / dependency | SRC-008 | Shows that data-center deployment depends on regulated infrastructure decisions and system planning. | Does not prove preferential treatment or improper approval. | Strong |
| REL-037 | State/local governments | Tax policy / land use / approvals | Data-center developers | Public policy / economic incentives | SRC-007 | Documents how policy choices can shape data-center siting and concentration. | Does not prove subsidies are the sole cause of investment or that every incentive lacks public benefit. | Strong |
| REL-038 | Public ratepayers / taxpayers | Cost exposure via infrastructure / incentives | Data-center ecosystem | Economic / distributed consequence | SRC-007; SRC-008 | Supports the possibility that some public costs are socialized through grid/infrastructure/tax policy. | Does not quantify all public exposure or prove private actors capture all upside. | Supported synthesis |
| REL-039 | Palantir / data platforms | Data integration / modeling / workflow | Agency users / human decision-makers | Operational / decision support | SRC-013; SRC-025 | Documents that platforms can shape what information is linked, surfaced, prioritized, and made actionable. | Does not mean the software makes every legal or final human decision. | Strong |
| REL-040 | Agency / customer | Legal authority / permissions / configuration | Palantir or other vendor platform | Decision rights / governance | SRC-013; SRC-025 | Clarifies that customer law, contracts, permissions, and configuration govern access and use. | Does not eliminate vendor influence over practical workflow or technical dependency. | Strong |
| REL-041 | Cloud provider | Hosting / infrastructure | Agency workload | Infrastructure / operational | SRC-011; SRC-030 | Shows private infrastructure can host public functions under government security requirements. | Does not establish provider authority over the legal purpose of the workload. | Strong |
| REL-042 | Agency / contractor / cloud provider / data source / model provider / human reviewer | Distributed decision chain | Affected individual | Decision rights / administrative consequence | SRC-013; SRC-016; SRC-025; SRC-027; SRC-030; SRC-031 | Supports the paper’s core point that accountability can be distributed across multiple actors while the person experiences one outcome. | Does not prove every adverse outcome is automated, unlawful, or unreviewable. | Cross-source synthesis |
| REL-043 | Infrastructure / standards / vendors / procurement pathways | Lower implementation friction | Future authorized use | Capability-before-policy | SRC-011; SRC-012; SRC-013; SRC-015; SRC-030 | Supports the claim that preexisting rails can reduce the engineering and procurement burden of future uses. | Does not prove a future controversial use will be authorized, lawful, or implemented. | Core synthesis |
| REL-044 | Cross-partisan elite networks | Private proximity / access | Public officials + private capital + technology actors | Institutional / political | SRC-034; SRC-037; SRC-038; SRC-039 | Documents that public partisan divisions can coexist with private cross-party institutional proximity. | Does not establish one 'uniparty,' coordinated agenda, or shared ideology. | Core synthesis |
| REL-045 | Separate systems | Interoperability mechanisms | Combined institutional capability | Technical / institutional | SRC-013; SRC-015; SRC-016; SRC-019; SRC-023; SRC-025; SRC-030; SRC-031 | Supports the investigation’s central thesis that systems can become jointly consequential without formal merger or one owner. | Does not establish that all systems are currently connected or centrally controlled. | Core cross-paper synthesis |

## Relationship Families

- **Defense / intelligence cooperation:** REL-001, REL-002, REL-003, REL-004, REL-005
- **Palantir / government / platform:** REL-006, REL-007, REL-008, REL-009, REL-039, REL-040
- **Cloud / deployment infrastructure:** REL-010, REL-011, REL-012, REL-013, REL-041
- **Identity / financial / surveillance rails:** REL-014, REL-015, REL-016, REL-017, REL-018, REL-019
- **Administrative categories / civil liberties:** REL-020, REL-021, REL-022, REL-023
- **Dialog / elite networks:** REL-024, REL-025, REL-026, REL-027, REL-028, REL-029, REL-030, REL-031, REL-044
- **Capital / founders / defense technology:** REL-032, REL-033, REL-034
- **Data-center physical / economic infrastructure:** REL-035, REL-036, REL-037, REL-038
- **Cross-system architecture / decision rights:** REL-042, REL-043, REL-045

## Edges Requiring Careful Public Language

- **REL-003:** Intelligence sharing is not civilian-data sharing. Always identify the specific covered domains and legislative status.
- **REL-005:** Palantir–Israel partnership is direct and documented; do not extend it into every U.S.–Israel program without a separate edge.
- **REL-008:** ICE use is documented; do not infer foreign access or universal immigration-data access.
- **REL-012:** Commercial providers support classified government environments; do not imply ordinary commercial data is pooled into those environments.
- **REL-020:** Multi-agency antisemitism enforcement exists; do not claim protected criticism of Israel by citizens is itself unlawful.
- **REL-024:** Dialog’s cross-sector reach is documented; participant status varies and some people dispute involvement.
- **REL-028:** Booker is reported/listed, not a cofounder; present record does not establish compensation.
- **REL-044:** Cross-party proximity supports an 'above partisan boundaries' inquiry, not a factual conclusion that a single uniparty exists.
- **REL-045:** Interoperability is the architecture question; do not turn technical possibility into a claim of one existing integrated machine.

## Strongest Fiber Edges

These are the relationships most useful for seeing the larger architecture without overstating it:

- **REL-003: U.S. Senate Intelligence Committee / S. 4615 §622 → Proposed intelligence-sharing enhancement → Israel** — Documents a proposed expansion/enhancement of intelligence sharing with Israel in specified domains.
- **REL-005: Palantir Technologies → Strategic partnership / technology support → Israel Ministry of Defense** — Documents a direct Palantir–Israeli defense relationship in support of war-related missions.
- **REL-009: Palantir Foundry / integration services → Federal Aviation Administration Logistics Center → Commercial / data integration** — Does not establish access to all FAA or federal data.
- **REL-010: Google Public Sector → Cloud infrastructure / accredited hosting pathway → Palantir FedStart** — Documents a layered relationship combining Google Cloud infrastructure with Palantir’s federal deployment offering.
- **REL-012: AWS / Google / Microsoft / Oracle → JWCC contracts → U.S. Department of Defense** — Documents commercial cloud providers supporting DoD workloads across multiple classification levels.
- **REL-014: NIST credential service provider model → Federation / assertions → Separately administered relying parties** — Documents a technical model for identity attributes/authentication to be recognized across separately administered systems.
- **REL-019: Fusion centers → Information-sharing mechanisms → Federal / state / local / tribal / territorial / private-sector partners** — Documents an institutional model designed to move information across organizational boundaries.
- **REL-024: Dialog → Private invitation-based network → Technology / finance / government / defense / media / foreign officials** — Documents a cross-sector environment in which powerful actors from different institutions and parties are connected.
- **REL-026: Dialog → Ranking / relationship tracking / algorithmic introductions / pricing → Dialog participants** — Documents internal use of participant data, classifications, relationship management, and algorithmic recommendations to shape access and introductions.
- **REL-035: Data-center developers / hyperscalers → Large-load demand → Utilities / grid operators** — Documents how large compute demand creates grid-planning, interconnection, and cost-allocation consequences.
- **REL-039: Palantir / data platforms → Data integration / modeling / workflow → Agency users / human decision-makers** — Documents that platforms can shape what information is linked, surfaced, prioritized, and made actionable.
- **REL-042: Agency / contractor / cloud provider / data source / model provider / human reviewer → Distributed decision chain → Affected individual** — Supports the paper’s core point that accountability can be distributed across multiple actors while the person experiences one outcome.
- **REL-043: Infrastructure / standards / vendors / procurement pathways → Lower implementation friction → Future authorized use** — Supports the claim that preexisting rails can reduce the engineering and procurement burden of future uses.
- **REL-044: Cross-partisan elite networks → Private proximity / access → Public officials + private capital + technology actors** — Documents that public partisan divisions can coexist with private cross-party institutional proximity.
- **REL-045: Separate systems → Interoperability mechanisms → Combined institutional capability** — Supports the investigation’s central thesis that systems can become jointly consequential without formal merger or one owner.

## Open Relationship Questions

- Which actual systems, interfaces, and data categories are implicated when House/Senate defense-technology proposals move from research toward incorporation into systems or programs of record?
- What technical and legal mechanisms implement U.S.–Israel intelligence sharing under current agreements, and which data classes are expressly excluded?
- Where do Palantir deployments share common architecture, and where are customer environments technically and legally isolated?
- Which public agencies have meaningful portability, export, termination, and audit rights when core workflows are built on private platforms?
- Which identity, location, financial, and administrative systems can lawfully query or consume outputs from one another today?
- When a category, risk flag, or investigative lead is created in one administrative context, what rules prevent secondary use elsewhere?
- For serving officials participating in private networks such as Dialog, what ethics, gift, travel, fee, disclosure, and conflict rules apply?
- Which Dialog relationships produced later investments, appointments, contracts, policy collaborations, or procurement relationships? No causal inference should be made without a documentable edge.
- Where do public costs and private gains sit in specific utility, tax, land, and infrastructure arrangements around large data-center projects?

## Next Backend File

Build `05_INFRASTRUCTURE_PROJECT_LEDGER.md` to track named data-center, grid, cloud, defense, identity, payment, and platform projects with fields for location, owner/operator, customer/workload, physical resource demands, financing/incentives, public approvals, secrecy/confidentiality conditions, status, decision rights, source IDs, what is confirmed, and what remains unresolved.


---

## 2026 SWEEP RELATIONSHIP ADDITIONS

| Edge ID | Actor A | Mechanism | Actor B | Relationship type | Source ID(s) | What the edge proves | What it does NOT prove |
|---|---|---|---|---|---|---|---|
| REL-046 | OpenAI | announced operational responsibility | Stargate | Corporate operating role | SRC-041; SRC-042 | OpenAI was assigned the announced operational role. | Does not establish ownership of every site or power/customer contract. |
| REL-047 | SoftBank | financial responsibility + initial equity | Stargate | Corporate finance | SRC-041; SRC-042 | SoftBank is a lead financial partner and initial equity funder. | Does not establish full funding, guarantees, or control of every site. |
| REL-048 | Oracle | cloud + 4.5-GW development agreement | Stargate / OpenAI | Infrastructure / cloud / development | SRC-043; SRC-047 | Oracle is a key Stargate infrastructure partner. | Does not establish ownership of all Stargate sites or OpenAI workloads. |
| REL-049 | DOE | federal land / site access | SB Energy Portsmouth project | Public land / siting | SRC-050; SRC-051 | Federal land is part of project architecture. | Does not establish a federal defense workload or public ownership of the private campus. |
| REL-050 | SB Energy | stated payment for infrastructure | AEP Ohio | Customer-funded grid infrastructure | SRC-052; SRC-053 | AEP says SB Energy will fund stated $4.2B infrastructure. | Does not prove all future grid/system risk is private. |
| REL-051 | Entergy Louisiana | approved infrastructure/service arrangement | Meta Richland Parish | Utility / regulated service | SRC-056; SRC-057 | Utility/regulatory system is adapting to serve Meta’s campus. | Does not establish permanent customer savings or final lifetime cost allocation. |
| REL-052 | Meta | nuclear agreements | multiple nuclear projects | Energy procurement | SRC-058 | Meta is pursuing nuclear supply tied to AI demand. | Does not establish that every announced GW is new, dedicated or operating. |
| REL-053 | Oracle | Bloom fuel-cell arrangement | Project Jupiter | Dedicated-power strategy | SRC-047; SRC-048 | Oracle publicly associates fuel cells with the Michigan project. | Does not establish fuel-cell MW, configuration, emissions or operating status. |
| REL-054 | Box Elder County / MIDA | project-area authorization | Stratos | Local development authority | SRC-060 | Stratos has crossed an initial institutional authorization threshold. | Does not establish final permits, financing, power or construction. |
| REL-055 | Kevin O’Leary | public promotion / developer-side leadership | Stratos | Project promotion / development | SRC-061; SRC-062; SRC-063 | O’Leary is materially associated with the proposal. | Does not establish exact ownership, lender backing or delivered capacity. |
| REL-056 | White House | permitting acceleration policy | qualifying data-center + power projects | Federal policy | SRC-059 | Federal government created a route intended to accelerate qualifying infrastructure. | Does not itself approve a site or erase state/local constraints. |

---

## 2026-09-30 PALANTIR / PLATFORM RELATIONSHIP RECONCILIATION

| ID | Actor / system A | Relationship | Actor / system B | Evidence state | Source ID(s) | What is established | What remains unestablished |
|---|---|---|---|---|---|---|---|
| REL-057 | Palantir | Maven Smart System contract / licenses | U.S. Department of Defense | DIRECTLY DOCUMENTED | SRC-068 | Direct procurement relationship at substantial scale. | Scope of every deployment; autonomous decision authority; universal access. |
| REL-058 | Palantir | Enterprise Agreement | U.S. Army | DIRECTLY DOCUMENTED | SRC-070 | 75 contracts consolidated; up to ten years; $10B max potential vehicle. | Obligated spend of $10B; implementation of every contemplated use. |
| REL-059 | Palantir Foundry | Edge-to-cloud data mesh component | Army NGC2 common data baseline | DIRECTLY DOCUMENTED | SRC-071 | Foundry appears inside a named command-and-control data architecture. | Sole control, unrestricted access, all data sources, all users. |
| REL-060 | Palantir / ImmigrationOS | Operational platform / mission areas | ICE | DIRECTLY DOCUMENTED | SRC-072 | Targeting/prioritization, self-deportation tracking, immigration lifecycle functions. | Exact source-data map, all user permissions, State Dept control. |
| REL-061 | Palantir | Strategic wartime technology relationship | Israel Ministry of Defense | DIRECTLY DOCUMENTED | SRC-028; SRC-074 | Partnership and company-described support for war-related / ongoing-war missions. | Direct role in Gospel, Lavender, Where's Daddy, or U.S. legislative provisions. |
| REL-062 | H.R. 8800 §219 / S. 4784 §1217 | Institutional adjacency / capability overlap | Existing Palantir U.S. military + Israel MoD footprint | SYNTHESIS — BOUNDED | SRC-019; SRC-020; SRC-068; SRC-070; SRC-071; SRC-028; SRC-074 | Palantir occupies relevant institutions and technical domains on both sides of contemplated cooperation. | No named Palantir implementation role, award, designation, or executive-agent position established. |
| REL-063 | S. 4615 §622 | Capability overlap | Palantir intelligence / defense data-integration capabilities | SYNTHESIS — WEAKER EDGE | SRC-023; SRC-024; SRC-025 | Technical-domain overlap exists. | No Palantir role in §622 intelligence-sharing mechanism established. |
| REL-064 | State Dept Catch and Revoke | Separate program boundary | Palantir / ICE work | DIRECT DENIAL + STRUCTURAL CONTEXT | SRC-073; SRC-072 | Palantir denies operating State's program while separately performing ICE mission work. | Exact downstream data exchanges or operational handoffs between separate systems. |
| REL-065 | Government authority | Distributed implementation chain | procurement / contractor / software / data / human execution | STRUCTURAL SYNTHESIS | SRC-070; SRC-071; SRC-072; SRC-073 | Demonstrates that consequential functions can be distributed across institutions. | Deliberate concealment, shell-company behavior, or unlawful evasion absent specific evidence. |

### Relationship rule carried forward
**No line on the map should mean more than the evidence behind that line.** The §219 / §1217 / §622 rows are therefore intentionally classified as adjacency / overlap, not implementation.



---

## 2026-10-02 POLITICAL-FINANCE RELATIONSHIP ADDENDUM

| ID | Relationship | Type | Status | Source(s) | What is established | Boundary / unresolved |
|---|---|---|---|---|---|---|
| REL-066 | Meta Platforms Inc. → Jeff Landry | Corporate-entity contribution | A — primary verified | SRC-078, SRC-086 | Two $12,000 contributions on Oct. 27, 2025; total $24,000; after Dec. 4, 2024 Meta announcement / tax action. | Purpose, motive, corporate-treasury characterization and causal effect not established. |
| REL-067 | Georgia Power → Georgians First Leadership Committee → Brian Kemp association | Utility political finance / leadership committee | A — primary verified | SRC-079, SRC-080 | $18,000 + $20,000 in 2021; committee registered as PAC; Brian Kemp listed as chairperson. | Not a direct contribution to Kemp's candidate committee; no inference that contributions caused 2024 veto. |
| REL-068 | NorthPoint Development ↔ Shapiro administration / Keystone Trade Center | Developer ↔ state permitting relationship | A for project-policy relation | SRC-081 | NorthPoint executives and Shapiro/DEP publicly linked at future AWS site; administration states it worked with NorthPoint to accelerate / coordinate permits. | This relationship is not itself political finance. |
| REL-069 | NorthPoint Development → Shapiro for Pennsylvania | Reported developer contribution | C — provisional | SRC-082, SRC-083, SRC-086 | Reported $100,000 contribution lead; relevant PA campaign report exists. | Exact legal donor, itemized row, date, amendment/refund status remain unverified; no causal inference. |
| REL-070 | IBEW Local 26 → Ann Wheeler | Labor political support | C — secondary compilation | SRC-084, SRC-086 | Reported $55,000 support in 2023 cycle. | Not QTS, Compass, Blackstone, developer, landowner or investor money absent separate evidence; recipient-side row pending. |
| REL-071 | AIPAC PAC → federal officials in defined data-center-jurisdiction universe | Federal electoral support overlap | VERIFIED within Pass 2A universe | SRC-075, SRC-076 | 26 of 38 reviewed current/action-time federal officials had documented direct AIPAC PAC treasury contributions. | Most were not Pass 1 project facilitators; not industry money, not proof of project influence, motive, coordination or causation. |
| REL-072 | United Democracy Project ↔ defined Pass 2A universe | Independent-expenditure audit | No relevant IE located in reviewed universe | SRC-076 | No supporting IE for listed officials and no IE opposing listed officials' opponents was located in reviewed files. | Universe-specific negative; not a claim that UDP had no activity elsewhere. |
| REL-073 | Data Center Coalition ↔ data-center policy environment | Trade-association / sector-policy advocacy | B — stated policy posture | SRC-085 | Association publicly advocates policy conditions relevant to data-center growth. | Do not attribute all association positions to every member or to a specific project without lobbying records. |
