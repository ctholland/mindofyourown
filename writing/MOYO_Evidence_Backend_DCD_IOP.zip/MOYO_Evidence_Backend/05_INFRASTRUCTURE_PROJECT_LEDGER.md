# DATA CENTER DISCONNECT — INFRASTRUCTURE / PROJECT LEDGER

**Project:** The Data Center Disconnect and the Dystopian Debacle / The Architecture of Interoperable Power  
**Author:** C.T. Holland / Mind Of Your Own®  
**Backend location:** `04_EVIDENCE_BACKEND/05_INFRASTRUCTURE_PROJECT_LEDGER.md`  
**Evidence controls:** `01_MASTER_SOURCE_REGISTER.md`, `02_MASTER_CLAIM_LEDGER.md`, `03_MASTER_TIMELINE.md`, `04_RELATIONSHIP_LEDGER.md`  
**Status:** Current-project ledger built from the evidence already inside the two papers and backend. It is intentionally **not yet a national project census**. A fresh national sweep can be layered onto this later without changing the ledger structure.

## Governing Rule

Keep **owner/developer**, **tenant/customer/workload**, **physical infrastructure**, **financing/incentives**, **legal authority**, and **decision rights** separate. Announced capacity is not operating capacity. Proposed legislation is not enacted law. A vendor relationship is not proof of data access beyond the documented scope.

## Project Ledger

| Project ID | Project / system | Location | Owner / operator | Known customer / workload | Type | Announced / documented | Current status | Operating horizon | Footprint / scale | Power / load | Utility / infrastructure | Financing / incentives | Key dependencies / data / authority | Source ID(s) | What is confirmed | What remains unproven | Evidence status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| PRJ-001 | U.S. data-center buildout — national baseline | United States | Multiple hyperscalers / developers | AI, cloud, enterprise, mixed | National infrastructure | Operating + expanding | 2023–2030 scenarios | N/A national aggregate | 176 TWh in 2023; ~192 TWh in 2024 estimate; large projected growth | National electricity share ~4.4% in 2023; projected materially higher | DOE/LBNL / utility systems | Varies | Grid planning, generation, transmission, water/cooling, land | SRC-002; SRC-003; SRC-004 | Confirms rapid national scale and growth | Does not identify individual project economics or workloads | High-confidence aggregate |
| PRJ-002 | Northern Virginia data-center cluster | Northern Virginia | Multiple operators / hyperscalers | Cloud, enterprise, mixed | Regional cluster | Operating + expanding | Current | Large multi-campus regional footprint | One of the largest global concentrations | High regional electricity concentration | Dominion / PJM / local utilities | Virginia sales-and-use-tax exemption and local policy environment | Land, power, transmission, tax policy | SRC-007 | Explains concentration through fiber, electricity, land, proximity, and tax policy | Does not prove tax policy alone caused the cluster or every local project is beneficial/harmful | High confidence |
| PRJ-003 | Large-load grid integration proceedings | U.S. FERC-jurisdictional regions | Utilities / grid operators / large-load customers | Data centers and other large loads | Regulatory / grid enabling infrastructure | Active | 2026 onward | N/A | Large-load interconnection and tariff treatment | Material enough to trigger FERC action | FERC / RTOs / utilities | Rate design / interconnection / cost allocation | Grid planning, financial assurance, ratepayer exposure | SRC-008; SRC-009 | Confirms large-load integration has become a federal regulatory issue | Does not establish wrongdoing or final findings for any specific project | High confidence; SRC-009 URL needs capture |
| PRJ-004 | Microsoft global AI/cloud infrastructure expansion | United States + global | Microsoft | Azure / AI / cloud customers | Hyperscaler infrastructure | Operating + expanding | Ongoing | Large global portfolio | Major continuing capex and data-center footprint | Not fully project-specific in current backend | Utilities across multiple markets | Private capex; public incentives vary by site | Compute, land, power, cooling, fiber | SRC-010 | Confirms continuing hyperscaler capital commitment to AI/cloud infrastructure | Does not attribute all Microsoft capex to AI or identify site-level public costs | Needs stronger direct source capture |
| PRJ-005 | Google Cloud + Palantir FedStart | U.S. public-sector cloud environment | Google Public Sector + Palantir | Federal/public-sector software customers | Cloud / deployment platform | Announced 2025 | Available / deployment pathway | Ongoing | N/A | Software/cloud compliance infrastructure, not one physical campus | N/A direct load not separately stated | Google Cloud | Commercial service model | Cloud accreditation, compliance, software deployment | SRC-011; SRC-012 | Confirms layered public-sector deployment architecture combining private cloud and platform tooling | Does not establish unrestricted government-data access or a shared federal database | High confidence |
| PRJ-006 | FAA Logistics Center data modernization / AI integration | United States | FAA / contractor environment | FAA Logistics Center | Federal data-integration program | 2026 procurement | Procurement / implementation phase | 2026 onward | N/A | Palantir Foundry licenses + integration services | N/A | Government IT environment | Federal procurement | Data integration, analytics, AI-enabled decision support | SRC-013 | Confirms an enterprise requirement to integrate and analyze disparate operational systems | Does not establish access to all FAA/federal systems or autonomous decision authority | High confidence |
| PRJ-007 | Joint Warfighting Cloud Capability (JWCC) | United States / DoD cloud regions | AWS, Google, Microsoft, Oracle | U.S. Department of Defense | Defense cloud infrastructure | Awarded Dec. 7, 2022 | Active contract vehicle | 2022 onward | Distributed cloud infrastructure | Enterprise cloud across classification levels | Not publicly reducible to one load figure | Commercial cloud providers / DoD | Federal contracts | Unclassified, Secret, Top Secret cloud capability | SRC-030 | Confirms DoD reliance on multiple commercial cloud providers across classification levels | Does not imply pooling of ordinary commercial data with classified workloads | High confidence |
| PRJ-008 | Palantir TITAN | U.S. Army | Palantir Technologies | U.S. Army | Defense platform / ground-station program | Prototype award Mar. 6, 2024; production move Sep. 1, 2026 | Prototype → production | 2024–2026+ | N/A | $178.4M prototype award; later $127M production delivery order | N/A | Army tactical/mission infrastructure | Federal defense procurement | AI/data fusion / targeting / decision-support ground systems | SRC-025 | Confirms progression from competitive prototype to production relationship | Does not establish universal Army data access or Palantir control over targeting/legal authority | High confidence |
| PRJ-009 | ICE Investigative Case Management (ICM) | United States | ICE / Palantir-supported environment | U.S. Immigration and Customs Enforcement | Homeland-security case-management system | Documented before 2020; updated PIA 2020 | Operational / historically documented | Ongoing status to recheck | N/A | Investigative case-management / operational analytics | N/A | Federal IT environment | Federal procurement | Investigative records, case management, operational analysis | SRC-027 | Confirms Palantir-linked investigative infrastructure within ICE | Does not prove access beyond program authorities or any foreign-data pipeline | High confidence for documented period; recheck current state |
| PRJ-010 | NIST Digital Identity Federation standards | United States | NIST / implementing agencies and service providers | Government and private relying parties | Identity standards infrastructure | 2025 standards | Published / active guidance | 2025 onward | N/A | Federation and assertions model | N/A | Identity providers / relying parties | Standards, not direct subsidy | Identity proofing, authentication, federation | SRC-014; SRC-015 | Confirms technical standards enabling identity federation across separately administered systems | Does not create a universal national identity database | High confidence |
| PRJ-011 | FedNow Service | United States | Federal Reserve | Banks / financial institutions | Payment rail | Launched 2023 | Operational | 2023 onward | National payment network | Instant-payment infrastructure | N/A physical load relevance not central | Federal Reserve infrastructure | Public payment infrastructure | Real-time payments | SRC-017 | Confirms an instant-payment rail distinct from a CBDC | Does not establish a CBDC or unified programmable financial-control system | High confidence; policy context needs 2026 recheck |
| PRJ-012 | Fusion center network | United States | Federal, state, local partners | Law-enforcement / homeland-security stakeholders | Information-sharing infrastructure | Post-9/11 network; oversight documented 2012+ | Operational network | Ongoing | Distributed institutional network | Information-sharing capability | N/A | Federal/state/local systems | Public funding / support varies | Cross-jurisdiction information sharing | SRC-031 | Confirms an institutional architecture for information sharing across public and private partners | Does not prove unlawful sharing or a total surveillance system | High confidence |
| PRJ-013 | Flock Safety ALPR network | United States | Flock Safety + participating agencies | Law enforcement / public-safety customers | Location / surveillance platform | Ongoing | Operational / expanding | Current | Distributed camera network | Searchable vehicle-detection records across participating sources | N/A | Local agency networks / Flock platform | Agency contracts | Vehicle-location data, search, alerts | SRC-029 | Confirms searchable location capability across participating customer networks | Does not establish universal nationwide access or unrestricted search authority | Moderate; first-party / program-specific confirmation needed |
| PRJ-014 | U.S.–Israel Defense Technology Cooperation Initiative — House track | Federal legislative framework | U.S. House / DoD executive agent if enacted | U.S.–Israel defense-technology cooperation | Policy / acquisition framework | House-passed July 22, 2026 | Proposed / not enacted as of paper cutoff | Status dynamic | N/A | Research, development, testing, evaluation, industrial cooperation; pathways toward incorporation/procurement | N/A | DoD / participating institutions | Federal authorization / future appropriations | Defense technology, acquisition pathways, joint ventures, licensing | SRC-019; SRC-021 | Confirms House-passed framework and post-amendment wording | Does not establish enacted law, civilian-data access, or automatic system interoperability | High confidence; must recheck status |
| PRJ-015 | FUTURES Act — Senate track | Federal legislative framework | U.S. Senate / DoD if enacted | U.S.–Israel defense-technology cooperation | Policy / acquisition framework | 2026 | Proposed / Senate vehicle | Status dynamic | N/A | Related bilateral R&D/testing/evaluation/coordination/industrial cooperation | N/A | DoD / participating institutions | Federal authorization | Defense-technology cooperation | SRC-020; SRC-022 | Confirms separate Senate legislative pathway | Does not establish final enacted language or equivalence with House text | High confidence; must recheck status |
| PRJ-016 | U.S.–Israel intelligence-sharing enhancement — S. 4615 §622 | Federal legislative framework | President / DNI / SecDef if enacted | Israel + Abraham Accords cooperation in specified domains | Intelligence-sharing policy framework | Reported May 20, 2026 | Proposed / not final enacted law as of paper cutoff | Status dynamic | N/A | Specified intelligence-sharing domains | N/A | Intelligence / defense systems | Federal authority | Cyber, terrorism, sanctions evasion, technology proliferation, missile/UAS, air/space awareness | SRC-023; SRC-024 | Confirms proposed expansion/enhancement in enumerated areas | Does not establish general civilian-data access or a domestic-protest data pipeline | High confidence; must recheck status |
| PRJ-017 | Palantir–Israel Ministry of Defense strategic partnership | Israel / Palantir defense environment | Palantir + Israel Ministry of Defense | Israel defense missions | Defense-technology partnership | Jan. 12, 2024 | Documented partnership | 2024 onward; current scope not fully public | N/A | Technology support for war-related missions | N/A | Palantir / Israeli defense infrastructure | Commercial partnership | Data integration / decision-support technology scope not fully public | SRC-028 | Confirms direct Palantir–Israeli defense relationship | Does not prove scope across every Israeli system or any U.S. civilian-data connection | High confidence; scope opaque |
| PRJ-018 | Dialog network / Washington-area campus | Private network / Washington-area expansion | Dialog / Peter Thiel / Auren Hoffman network | Cross-sector members / invitees / participants | Elite-network institutional infrastructure | Operating since ~2005–06; campus reported 2026 | Operational network + reported expansion | Current | Private retreats, dinners, planned campus | Relationship / access infrastructure, not compute | N/A | Private venues / event infrastructure | Paid/tiered membership; pricing reportedly varies | Elite introductions, classification, relationship management | SRC-034; SRC-037; SRC-038; SRC-039 | Confirms an enduring cross-sector private institution with ranking/matching/access mechanisms | Does not prove unified ideology, policy coordination, corruption, or quid pro quo | Strong secondary reporting |

## Project Classes

- **Physical data-center / energy infrastructure:** PRJ-001, PRJ-002, PRJ-003, PRJ-004
- **Cloud / platform / procurement infrastructure:** PRJ-005, PRJ-006, PRJ-007, PRJ-008, PRJ-009
- **Identity / financial / surveillance rails:** PRJ-010, PRJ-011, PRJ-012, PRJ-013
- **U.S.–Israel defense / intelligence architecture:** PRJ-014, PRJ-015, PRJ-016, PRJ-017
- **Elite-network / relationship infrastructure:** PRJ-018

## Fields to Add During the Later National Sweep

- Exact site / county / parcel where relevant.
- MW/GW current load, contracted load, requested load, and ultimate campus load — kept separate.
- Water withdrawal, consumptive use, discharge, cooling type, and drought sensitivity.
- Onsite generation, backup generation, gas turbines, nuclear/SMR, behind-the-meter arrangements.
- Transmission/substation upgrades and who pays for them.
- Tax abatements, grants, PILOT agreements, sales-tax exemptions, land incentives, and other public support.
- Financing structure: corporate balance sheet, JV equity, project finance, private credit, bond financing, insurer/pension exposure.
- Developer versus owner versus tenant versus end customer.
- Announced versus permitted versus under construction versus energized versus operational capacity.
- NDA/confidentiality provisions, proprietary-information exclusions, classified annexes, or limited public disclosure.
- Initial approved phase versus later expansion / amendment / scale increase.
- Community opposition, litigation, moratorium, zoning denial, environmental review, or utility dispute.
- Cancellation, delay, downsizing, stranded-capacity, utilization, or changed demand assumptions.
- Government / defense / intelligence workload only where specifically documented.
- Exit / portability / audit / termination rights where a private platform performs a public function.

## Current Known Gaps

- The current main paper is strong on national energy/resource architecture but does not yet contain a comprehensive 2025–2026 census of named hyperscale campuses.
- Site-level financing, subsidies, water use, and transmission commitments are unevenly represented in the present backend.
- Secrecy/NDA and phased-expansion claims need more named primary-source case studies before they can be generalized project-by-project.
- Current 2026 status for several legislative and administrative items must be reverified immediately before publication.
- Current operating status and scope of ICE ICM, Flock deployments, and some Palantir government programs should be refreshed if they become central to the public package.
- The future national sweep should add projects only when they materially alter scale, resource, secrecy, financing, public-risk, defense/national-security, or demand-disconnect analysis. Do not turn this ledger into a directory of every data center.

## Sweep Rule for Later

When the fresh 2026 project sweep is performed, **update existing project/system rows where possible and add a new row only when a project materially changes the architecture**. The sweep should prioritize extraordinary scale, power/resource demand, public subsidy/risk, secrecy, phased expansion, unusual generation arrangements, financing, government/defense relevance, community conflict, delay/cancellation, and strategic importance.

## Next Backend File

Build `06_WHAT_DOESNT_CLICK_REGISTER.md` using the discipline: **DOCUMENTED FACT → ORDINARY EXPLANATION → WHAT REMAINS UNEXPLAINED → WHAT EVIDENCE WOULD RESOLVE IT.** This register should preserve anomalies without converting them into conclusions.


---

## 2026 SWEEP PROJECT ADDITIONS

| Project ID | Project / system | Location | Owner / operator | Known customer / workload | Type | Current status | Scale | What is confirmed / boundary | Source ID(s) |
|---|---|---|---|---|---|---|---|---|---|
| PRJ-019 | Stargate I / Abilene | Abilene, Texas | OpenAI / Oracle / Crusoe-associated | OpenAI workloads | Operating AI compute | Partially operating | Exact MW unresolved | OpenAI reports active training/inference workloads; site-level utility, ownership, incentives and full water terms unresolved. | SRC-045; SRC-047 |
| PRJ-020 | Stargate network expansion | Multi-state U.S. | OpenAI / Oracle / SoftBank / MGX + site partners | OpenAI compute / OCI-associated | Multi-site AI infrastructure | Mixed: operating / construction / development / announced | 4.5 GW additional development announcement; nearly 7 GW planned in Sept. 2025; broader targets later | Aggregate figures are pipeline/company measures, not operating load. | SRC-041; SRC-042; SRC-043; SRC-044; SRC-046 |
| PRJ-021 | Project Jupiter / Saline Township | Michigan | Oracle + OpenAI + Related Digital + Blackstone + Walbridge | AI / cloud | Fuel-cell-linked AI campus | Construction milestone documented | Exact MW unresolved | Illustrates alternative power strategy; fuel-cell size/grid role not yet public. | SRC-047; SRC-048; SRC-049 |
| PRJ-022 | Portsmouth / Piketon AI campus | Pike County, Ohio | SB Energy / SoftBank-linked; federal site | AI data-center campus; end customer unresolved | Federal-land + customer-funded grid buildout | Announced / development | $4.2B AEP infrastructure plan; exact MW unresolved | Strongest new public/private infrastructure case; final customer, MW, water, financing and binding protections unresolved. | SRC-050; SRC-051; SRC-052; SRC-053; SRC-054 |
| PRJ-023 | Meta Richland Parish expansion | Louisiana | Meta / Entergy service environment | Meta AI/data-center workload | Hyperscaler multi-GW expansion | Under construction / expanding | Stated future 5-GW compute target | Compute target is not current electric load; lifetime cost allocation unresolved. | SRC-055; SRC-056; SRC-057 |
| PRJ-024 | Meta nuclear portfolio | Multi-state U.S. | Meta + project counterparties | Meta AI infrastructure | Firm-power procurement strategy | Announced agreements | Up to 6.6 GW portfolio claim | Must disaggregate existing generation, extensions, uprates and development-stage projects. | SRC-058; SRC-067 |
| PRJ-025 | Stratos | Box Elder County, Utah | O’Leary-associated developer-side project | No named tenant verified | Mega-proposal / governance conflict | Initial project-area authorization; not operating | Public reporting: 3-GW Phase 1 / up to 9-GW Utah target | Financing, firm power, water, permits and anchor tenancy unresolved. | SRC-060; SRC-061; SRC-062; SRC-063 |
| PRJ-026 | New York large-data-center pause | New York State | State policy | Covered future projects | State-level governance counterforce | Reported policy action | Reported 50-MW threshold; direct state text still required | Scope, exemptions and legal implementation unresolved. | SRC-064; SRC-065 |
| PRJ-027 | AEP Ohio large-load tariff / screening framework | Ohio | AEP Ohio / PUCO environment | Large data-center loads | Utility-governance infrastructure | Active regulatory framework | N/A | Shows grid operator effort to allocate costs and distinguish committed from speculative load. | SRC-054 |

---

## 2026-09-30 RECONCILIATION NOTE — NO NEW PHYSICAL PROJECT ROW CREATED

The September 30 Palantir reconciliation adds **platform, procurement, command-and-control, immigration, and U.S.–Israel relationship evidence**, not a new physical data-center project. No artificial project row has been created here merely to force every new finding into the Infrastructure / Project Ledger.

Cross-reference only:
- Government / defense compute and platform demand remains relevant to **Q-024** in the Open Questions file.
- Maven, Army Enterprise Agreement, NGC2 / Foundry, ImmigrationOS, and Israel MoD belong in the **Source Register, Claim Ledger, Timeline, Relationship Ledger, What Doesn't Click Register, and Open Questions**.
- Physical-project status vocabulary remains unchanged: **announced ≠ planned ≠ permitted ≠ under construction ≠ energized ≠ operating**; compute capacity, utility load, generation capacity, and operating consumption remain distinct measures.



---

## 2026-10-02 POLITICAL-FINANCE OVERLAY — PROJECT LEDGER DELTA

This overlay does not redefine the project ledger. It adds the currently documented political-finance / lobbying status to projects already in the infrastructure universe.

| Project / policy environment | Facilitating actor(s) | Connected economic actors | Political-finance / lobbying finding | Grade | Timing | Boundary |
|---|---|---|---|---|---|---|
| Meta Hyperion / Richland Parish, Louisiana | Jeff Landry; Jay Morris; LPSC / state actors in Pass 1 | Meta; Laidley LLC; Entergy | Meta Platforms Inc. → Landry $24,000 verified; reported Meta → Morris $3,500 remains provisional pending 2026 recipient-side filing. | A for Landry; C for Morris | Landry contribution after Dec. 2024 project announcement / tax action | Contribution timing does not establish motive or causation; Morris item remains provisional. |
| AWS / Keystone Trade Center, Pennsylvania | Josh Shapiro; Steve Santarsiero; Jim Prokopiak; Falls Township actors in Pass 1 | AWS / Amazon; NorthPoint; Talen | State permitting relationship with NorthPoint is primary-record documented; reported NorthPoint → Shapiro $100,000 remains transaction-level provisional. | A project-policy / C money | Contribution date unresolved; permitting activity documented in 2025 | Do not merge NorthPoint with Amazon as donor; do not infer contribution caused permit acceleration. |
| Microsoft / statewide data-center policy, Georgia | Brian Kemp; Georgia PSC / state actors in Pass 1 | Microsoft; Georgia Power / Southern | Georgia Power → Georgians First Leadership Committee $38,000 across two 2021 contributions, verified. | A | Before Kemp's 2024 data-center-tax veto | Leadership-committee contribution, not direct candidate money; no causal inference. |
| Prince William Digital Gateway, Virginia | Ann Wheeler / approving board majority | QTS; Compass; Blackstone | IBEW Local 26 → Wheeler $55,000 reported in 2023 cycle; remains secondary-compilation / primary-verification pending. | C | Broadly during project controversy / approval period; exact transaction timing normalization pending | Labor support is not QTS / Compass / Blackstone money. |
| Multi-jurisdictional federal overlay | Federal representatives / senators surrounding Pass 1 jurisdictions | N/A — not a project-economic actor category | AIPAC PAC direct support documented for 26 of 38 reviewed current/action-time federal officials; no relevant UDP IE found in reviewed universe. | Verified within Pass 2A universe | Multi-cycle, 2022–2026 | Outer political-network overlay only; most federal officials were not documented Pass 1 project facilitators. |

### Pass 2C incomplete-universe note

No project row outside those above should be marked **NO DOCUMENTED CONNECTED RELATIONSHIP LOCATED** merely because the latest pass returned no new record. Indiana, Iowa, Ohio, South Carolina, Arizona, Texas, additional Georgia/Virginia rows, and outstanding Louisiana records still require itemized state/local campaign-finance and lobbying extraction before a negative finding is defensible.
