# Shared Evidence Backend — README

**C.T. Holland | Mind Of Your Own® | mindofyourown.com**

This package is the shared research record behind two connected papers:

* **The Data Center Disconnect and the Dystopian Debacle** (DCD) — the physical, economic, public-private, and computational infrastructure beneath the AI buildout.
* **The Architecture of Interoperable Power** (IOP) — the institutional, legislative, technical, and data relationships through which fragmented systems can produce concentrated effects.

One backend supports both papers. It has not been split into separate DCD and IOP versions.

## How to use it

The papers themselves contain the publication citations (footnotes). This backend preserves the wider research record behind them: sources, claim-by-claim evidence status, chronology, relationships, projects, anomalies, and open questions. Read the files in numerical order; later files cite the source IDs defined in file 01.

## The seven files

1. `01_MASTER_SOURCE_REGISTER.md` — The stable source layer: every source used, with a persistent ID and a note on how much weight that kind of source can bear.
2. `02_MASTER_CLAIM_LEDGER.md` — Each claim classified as documented fact, mechanism, implication, synthesis, open question, boundary, or unproven, with what the evidence does not prove.
3. `03_MASTER_TIMELINE.md` — A chronology showing sequence, layering, and acceleration, built on the rule that chronology is not causation.
4. `04_RELATIONSHIP_LEDGER.md` — Actor-to-actor edges (Actor A → mechanism → Actor B), each stating what the relationship proves and what it does not.
5. `05_INFRASTRUCTURE_PROJECT_LEDGER.md` — The data-center and infrastructure projects covered by the papers, keeping owner, tenant, physical build, financing, legal authority, and decision rights separate. It is not a national project census.
6. `06_WHAT_DOESNT_CLICK_REGISTER.md` — Anomalies and discrepancies in the record, each paired with the ordinary explanation, what remains unexplained, and the evidence that would resolve it.
7. `07_OPEN_QUESTIONS_AND_UNRESOLVED_CLAIMS.md` — The active research queue: what remains open, what evidence is needed, and where answers would be routed.

## Scope and currency

This shared backend supports both final papers: *The Data Center Disconnect and the Dystopian Debacle* and *The Architecture of Interoperable Power*. The seven files were last reconciled on October 2, 2026. The final papers were completed on October 12–13, 2026. For publication citations and for final status language, including legislative status as of October 12, 2026, the papers' footnotes control.

## Reading rules that govern all seven files

* Documented is not the same as proved to be coordinated.
* Capability is not authorization, implementation, or use.
* Proximity, a common vendor, or a contract is not control or proven data access.
* Proposed legislation is not enacted law. Announced capacity is not operating capacity.
* Evidence grades describe documentation status, not wrongdoing.

## Credit

Mind Of Your Own® is created by C.T. Holland and is a trademark of Fairfield and Company LLC.
