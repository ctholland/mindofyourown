# DATA CENTER DISCONNECT — OPEN QUESTIONS & UNRESOLVED CLAIMS

**Project:** The Data Center Disconnect and the Dystopian Debacle / The Architecture of Interoperable Power  
**Author:** C.T. Holland / Mind Of Your Own®  
**Backend location:** `04_EVIDENCE_BACKEND/07_OPEN_QUESTIONS_AND_UNRESOLVED_CLAIMS.md`  
**Status:** Active research queue consolidated from the claim ledger, timeline, relationship ledger, infrastructure/project ledger, and What Doesn't Click register.  

## Governing Rule

This is the **research queue**, not a conclusions file. Each item stays open until primary or high-quality evidence resolves, narrows, weakens, or kills it. Do not preserve a theory merely because it is interesting. Do not discard an anomaly merely because an ordinary explanation is plausible. When an item resolves, route the result into the existing canonical backend file rather than creating a new methodology document.

## Active Queue

| ID | Priority | Lane | Open question / unresolved claim | Evidence needed | Likely primary-source targets | Current backend refs | Destination if resolved | Resolution test |
|---|---|---|---|---|---|---|---|---|
| Q-001 | CRITICAL | Demand / ghost-demand | How much of the current and announced data-center buildout is supported by contracted or visible demand today, versus speculative, strategic, government/defense, or future product demand? | Project-level tenant commitments; contracted MW; utilization; revenue tied to infrastructure; cancellations/delays; underwriting assumptions. | Utility interconnection agreements; hyperscaler filings; developer financing docs; earnings calls; bond/private-credit materials. | WDC-001; CLM-013; CLM-014; CLM-015 | Main paper III / Project Ledger | Resolve, weaken, or sharpen demand disconnect. |
| Q-002 | CRITICAL | Grid / public risk | Who bears stranded-cost risk if major large-load projects are delayed, cancelled, downsized, or underutilized after transmission/generation commitments are made? | Termination liabilities; security deposits; utility cost-allocation rules; stranded-asset provisions; rate cases. | FERC dockets; RTO tariffs; state PUC filings; utility agreements; interconnection service agreements. | WDC-002; REL-035; REL-036; REL-038 | Main paper I–II / Project Ledger | Quantify public/private risk allocation. |
| Q-003 | HIGH | Subsidies / incentives | At named projects, how are tax benefits, utility upgrades, land incentives, water infrastructure, and other public support divided against measurable public benefits? | Project-specific incentive amounts; clawbacks; jobs; tax-base effects; infrastructure costs. | State/local development agreements; tax-abatement records; PILOT agreements; utility filings; county/city minutes. | WDC-003; REL-037; REL-038 | Main paper II / Project Ledger | Convert broad public/private argument into case-level proof. |
| Q-004 | CRITICAL | Secrecy / phasing | Which projects were materially committed before the public could see the full contemplated campus, load, water, or transmission footprint? | Initial applications vs later amendments; land assembly; utility requests; expansion phases; disclosure timing. | Planning/zoning files; development agreements; utility service requests; public-records requests; council/hearing records. | WDC-004; WDC-005 | Main paper IV / Project Ledger | Provide named secrecy/irreversibility case studies. |
| Q-005 | HIGH | NDA / confidentiality | Where do NDAs, trade-secret claims, proprietary filings, or security restrictions limit public understanding of projects using public resources or infrastructure? | Actual NDA clauses; redactions; protected filings; withheld terms; disclosure chronology. | Local contracts; PUC protective orders; FOIA/records responses; procurement documents; classified/unclassified annex descriptions. | WDC-005 | Main paper IV | Differentiate legitimate confidentiality from democratic invisibility. |
| Q-006 | CRITICAL | Interoperability | Which government systems can currently exchange data, assertions, queries, alerts, or outputs across agency/vendor boundaries, and under what controls? | API inventories; federation trust relationships; MOUs; shared identifiers; permissions; audit requirements. | Agency architecture docs; NIST implementation docs; procurement statements of work; PIAs; interagency agreements; IG reports. | WDC-008; REL-014; REL-018; REL-019; REL-045 | Main VI–IX / Companion | Map actual edges rather than theoretical possibility. |
| Q-007 | CRITICAL | Decision rights | Who can add connectors, change permissions, alter model thresholds, broaden query scope, change retention, or authorize secondary use in major public-sector platforms? | Admin roles; control matrices; change logs; governance documents; override paths. | Agency system-security plans; SOWs; admin manuals; audit reports; vendor/customer governance docs. | WDC-007; REL-039; REL-040; REL-042 | Main IX / Companion decision-rights section | Identify practical control rather than nominal ownership. |
| Q-008 | HIGH | Cloud concentration / lock-in | How portable are core government workloads built on private cloud/platform stacks? | Exit clauses; migration testing; data export rights; termination assistance; concentration-risk analysis. | Federal contracts; cloud migration plans; GAO/IG reviews; agency enterprise-architecture docs. | WDC-006; REL-010; REL-011; REL-012; REL-013 | Main V | Measure dependency and reversibility. |
| Q-009 | CRITICAL | U.S.–Israel defense tech | What technical interfaces, data dependencies, cybersecurity boundaries, update channels, and acquisition pathways would accompany technologies incorporated into U.S. systems/programs of record? | Program-selection criteria; interface-control docs; test/evaluation plans; data-rights terms; licensing/export-control terms. | Congressional reports; DoD acquisition docs; service program offices; GAO; DSCA/DoD records where public. | WDC-010; REL-001; REL-002 | Companion legislative section | Move from legislative language to implementation architecture. |
| Q-010 | CRITICAL | U.S.–Israel intelligence sharing | What exact intelligence products, datasets, technical systems, minimization rules, exclusions, retention rules, and onward-sharing limits govern current and proposed U.S.–Israel intelligence sharing? | Implementing agreements; product categories; minimization; audit; retention; oversight; suspension rules. | Statutory reports; DNI/DoD/State records; IG/oversight material; declassified agreements; congressional reports. | WDC-011; REL-003; REL-004 | Companion intelligence section | Bound the relationship precisely; test viral overclaims. |
| Q-011 | CRITICAL | Palantir cross-environment boundaries | Where are the technical/legal walls between Palantir deployments for U.S. agencies, defense programs, ICE, FAA, and Israel MOD? | Tenancy model; support access; data residency; personnel access; logging; deployment segregation; contract restrictions. | Customer contracts; Palantir security docs; FedRAMP/DoD accreditation records; PIAs; audit docs; customer statements. | WDC-012; REL-005; REL-006; REL-008; REL-009 | Both papers | Establish isolation vs reusable common layers without assuming data pooling. |
| Q-012 | HIGH | Identity attribute portability | Which identity attributes can migrate across separately administered systems, and under what purpose-limitation or consent rules? | Attribute schemas; claims lists; federation agreements; purpose limits; revocation and audit controls. | NIST implementation profiles; agency federation agreements; IdP/CSP docs; privacy assessments. | WDC-013; REL-014 | Main VII / Companion interoperability | Clarify what identity federation actually makes portable. |
| Q-013 | HIGH | Financial decision rights | As real-time payments, sanctions screening, fraud systems, and identity become more integrated, who can block, delay, reverse, or condition transactions, and what notice/appeal rights exist? | Network rules; freeze authorities; fraud-engine logic; error-resolution procedures; appeals. | FedNow operating procedures; bank terms; OFAC/AML rules; CFPB/EFTA materials; bank compliance docs. | WDC-014; REL-016 | Main VII / IX | Map financial permissions without collapsing into CBDC claims. |
| Q-014 | CRITICAL | Administrative category migration | When a label, complaint, investigative lead, or risk determination arises in one administrative system, what rules prevent secondary use in another system affecting citizens or residents? | Referral protocols; interagency sharing; watchlist rules; secondary-use restrictions; litigation discovery. | DOJ/State/DHS/Education policies; PIAs; interagency agreements; litigation records; IG reports. | WDC-015; REL-020; REL-021; REL-022; REL-023 | Companion dissent/citizens section | Test the category-migration hypothesis case by case. |
| Q-015 | HIGH | Dialog / elite networks | Which reported Dialog relationships later produced investments, appointments, contracts, lobbying contacts, procurement opportunities, or policy collaborations? | Attendance/association linked to later documented transactions or appointments. | Ethics disclosures; FEC; lobbying records; board/adviser bios; SEC; procurement databases; public calendars; correspondence. | WDC-016; WDC-017; REL-024; REL-026; REL-044 | Companion Dialog section | Move from proximity to documentable downstream edges. |
| Q-016 | HIGH | Dialog ethics / disclosure | What ethics, gift, travel, fee, reimbursement, and disclosure rules apply when serving U.S. officials attend private invitation-only networks such as Dialog? | Rules plus participant-specific disclosures where available. | OGE rules; Senate/House ethics manuals; agency ethics guidance; travel/gift disclosures; financial disclosures. | REL-024; REL-028; REL-029; REL-030 | Companion Dialog section | Distinguish ordinary private participation from disclosure/ethics issues. |
| Q-017 | CRITICAL | National project sweep | Which 2025–2026 U.S. data-center projects materially change the paper’s scale, resource, secrecy, financing, public-risk, or strategic picture? | Project name, developer/owner, site, MW/GW, status, power source, water, subsidy, financing, phasing, secrecy, tenants/workload, delays/cancellations. | Utility/PUC filings; county records; company releases; SEC; DOE/FERC/RTO; local planning files; reputable trade reporting. | PRJ-001–PRJ-004; WDC-001–WDC-005 | 05 Infrastructure Ledger | Update project ledger without turning it into a directory. |
| Q-018 | CRITICAL | Stargate | What is the actual 2026 status, site map, ownership/financing structure, contracted power, build schedule, tenants/workloads, utility commitments, public subsidies, and phased scale of Stargate-linked projects? | Primary project agreements and site-level records. | OpenAI/SoftBank/Oracle/Stargate announcements; utility/PUC filings; local approvals; SEC/financing records; DOE/FERC/RTO filings. | Sweep hook from 05/06 | 05 Infrastructure Ledger / Main paper if material | Determine whether Stargate materially changes national scale/demand/public-risk argument. |
| Q-019 | HIGH | Kevin O’Leary lead | What specific data-center or AI-infrastructure project(s) is Kevin O’Leary associated with, in what capacity, with what financing, scale, site, power requirements, and public-resource exposure? | Named project; ownership/investment role; committed capital; site; MW; permitting; utility; subsidy; partners. | Company filings/press releases; land/utility records; financing disclosures; interviews as lead only; local government records. | Sweep hook from 06 | 05 Infrastructure Ledger if verified | Either establish a real infrastructure edge or drop the lead. |
| Q-020 | HIGH | Behind-the-meter / onsite generation | Which major AI/data-center campuses are pursuing dedicated gas, nuclear, SMR, fuel-cell, or behind-the-meter generation, and who bears fuel, grid, emissions, and stranded-asset risk? | Named projects, MW, generation type, utility arrangement, permitting, financing. | PUC/FERC filings; environmental permits; utility interconnection docs; company agreements; NRC/DOE where applicable. | PRJ-001; WDC-002 | 05 Infrastructure Ledger / Main I–II | Strengthen physical disconnect and infrastructure-before-policy analysis. |
| Q-021 | HIGH | Cancellation / underutilization | Which major announced projects have been delayed, cancelled, downsized, or materially rescheduled in 2025–2026, and why? | Status changes; load reductions; financing issues; tenant loss; grid constraints. | Company filings; local permits; utility queue changes; RTO data; lender statements; credible reporting. | WDC-001; WDC-002 | 05 Infrastructure Ledger / Main III | Test demand assumptions with negative evidence, not just expansion headlines. |
| Q-022 | MEDIUM | Water / local resource strain | Which projects have the most consequential water withdrawals, consumptive use, discharge, cooling requirements, or drought exposure? | Site-level water quantities and source; cooling type; municipal infrastructure impacts. | Water permits; utility agreements; environmental reviews; local planning docs; company sustainability filings. | PRJ-001; PRJ-002 | 05 Infrastructure Ledger / Main I | Add site-level resource evidence where material. |
| Q-023 | HIGH | Financing / private credit | How are the largest new campuses financed, and where do banks, private credit, insurers, pension funds, infrastructure funds, or JV partners carry risk? | Debt/equity structure; lenders; covenants; securitization; lease obligations; guarantees. | SEC filings; bond docs; private-credit disclosures; rating-agency reports; project-finance documents. | WDC-003; PRJ-004 | Main II / 05 Infrastructure Ledger | Test private-upside/public-downside and changing-time-horizon hypotheses. |
| Q-024 | HIGH | Government / defense demand | What government, defense, intelligence, or national-security compute demand is publicly documented inside the current data-center expansion? | Contracts; dedicated regions; capacity commitments; agency cloud procurement; classified/unclassified boundary descriptions. | DoD/GSA/SAM.gov; agency cloud contracts; JWCC task orders; budget documents; GAO; company filings. | WDC-001; WDC-019; REL-012 | Main III / Companion physical substrate | Quantify documented public-sector demand without using it to explain unexplained commercial capacity by default. |
| Q-025 | MEDIUM | Who sees the whole system? | Which regulator, inspector general, congressional committee, or cross-agency body has authority to examine combined effects across infrastructure, identity, cloud, data integration, payments, and administrative decision systems? | Jurisdiction map; systemic-risk assessments; cross-agency review authority. | Statutes; committee jurisdiction; IG mandates; GAO reports; OMB/OIRA guidance; White House/OSTP governance docs. | WDC-018; WDC-020 | Main X–XI / Share package | Identify governance gap rather than merely describe fragmentation. |

## Research Order

- **CRITICAL:** Q-001, Q-002, Q-004, Q-006, Q-007, Q-009, Q-010, Q-011, Q-014, Q-017, Q-018
- **HIGH:** Q-003, Q-005, Q-008, Q-012, Q-013, Q-015, Q-016, Q-019, Q-020, Q-021, Q-023, Q-024
- **MEDIUM:** Q-022, Q-025

## Immediate Sweep Batch

When the fresh 2026 sweep begins, start with these five because they are most likely to materially change the paper or project ledger:

- **Q-017 — National project sweep:** Which 2025–2026 U.S. data-center projects materially change the paper’s scale, resource, secrecy, financing, public-risk, or strategic picture?
- **Q-018 — Stargate:** What is the actual 2026 status, site map, ownership/financing structure, contracted power, build schedule, tenants/workloads, utility commitments, public subsidies, and phased scale of Stargate-linked projects?
- **Q-019 — Kevin O’Leary lead:** What specific data-center or AI-infrastructure project(s) is Kevin O’Leary associated with, in what capacity, with what financing, scale, site, power requirements, and public-resource exposure?
- **Q-021 — Cancellation / underutilization:** Which major announced projects have been delayed, cancelled, downsized, or materially rescheduled in 2025–2026, and why?
- **Q-024 — Government / defense demand:** What government, defense, intelligence, or national-security compute demand is publicly documented inside the current data-center expansion?

## Resolution States

- **CONFIRMED:** primary/high-quality evidence directly supports the bounded claim.
- **SUPPORTED:** multiple reliable sources support the interpretation, but a key primary record remains unavailable.
- **NARROWED:** part of the original claim survives but must be restated more precisely.
- **WEAKENED:** new evidence makes the hypothesis materially less likely or less important.
- **DISPROVEN:** reliable evidence contradicts the claim; preserve the correction in the backend.
- **UNRESOLVED:** evidence remains insufficient.
- **NOT MATERIAL:** true or plausible but does not materially affect the investigation architecture; do not clutter the papers with it.

## Close-the-Loop Rule

When a question resolves: **UPDATE THE EXISTING CLAIM / RELATIONSHIP / PROJECT / TIMELINE ROW → RECORD THE NEW SOURCE ID → UPDATE WHAT DOESN'T CLICK → VERIFY THE TWO PAPERS ONLY IF THE RESULT CHANGES A MATERIAL FACT → CLOSE THE QUEUE ITEM.**

## Backend Status After This File

The evidence backend now has the seven core working documents needed before the fresh sweep:
- `01_MASTER_SOURCE_REGISTER.md`
- `02_MASTER_CLAIM_LEDGER.md`
- `03_MASTER_TIMELINE.md`
- `04_RELATIONSHIP_LEDGER.md`
- `05_INFRASTRUCTURE_PROJECT_LEDGER.md`
- `06_WHAT_DOESNT_CLICK_REGISTER.md`
- `07_OPEN_QUESTIONS_AND_UNRESOLVED_CLAIMS.md`

The next phase is not another backend architecture document. It is **fresh evidence collection / sweep**, followed by updates to these seven files and then the public share package.


---

## 2026 SWEEP RECONCILIATION — QUEUE CHANGES

### Close / convert to standing rule

- **Q-018 / Stargate — “Is Stargate real?”** CLOSED. It is a real initiative with an operating Abilene site, named expansion sites and a documented initial equity group. Keep the status taxonomy as a standing rule: **announced ≠ permitted ≠ under construction ≠ energized ≠ operating**.
- **Q-019 / Kevin O’Leary — “Is O’Leary merely commenting?”** CLOSED. He is materially associated with Stratos as a promoter/developer-side figure. The unresolved work is ownership, financing, utility, water, permits and tenant commitments.

### Narrow / continue

- **Q-018A — Stargate site-by-site status:** For every named site, separate operating, energized, under construction, contracted, permitted and announced capacity; obtain site-level SPV, utility, financing, incentive, water and land records.
- **Q-022A — Portsmouth ratepayer protection:** Obtain binding payment, collateral, cost-recovery and exit provisions behind the stated $4.2B customer-funded infrastructure plan.
- **Q-023A — Meta nuclear disaggregation:** Break the 6.6-GW portfolio into existing generation, extension, uprate, restart and new-build components with delivery dates and regulatory status.
- **Q-025A — Stratos fundamentals:** Obtain MIDA/project-area agreement, developer entities, utility/interconnection records, water rights, air permits, financing and tenant commitments.
- **Q-026A — New York pause:** Obtain the direct state order/text, covered-project definition, exemptions and implementation guidance before using as definitive legal fact.
- **Q-027A — Federal fast-track projects:** Identify which projects are receiving federal permitting acceleration and what environmental/state/local review survives acceleration.

### New standing measurement question

- **Q-028 — Capacity vocabulary:** For every large project, identify whether a public GW figure means IT load, compute capacity, facility load, contracted/requested utility load, generation nameplate capacity, or ultimate campus potential. Never compare unlike categories as if they were equivalent.

### Publication impact

- **Main paper:** Add bounded Stargate example; Portsmouth/Piketon public-private case; Meta/Entergy cost-allocation case; explicit capacity-vocabulary sentence. Add New York only after primary state confirmation.
- **Companion paper:** Add one short strategic-compute paragraph; use development-vs-operating distinction; use federal permitting acceleration as a capability-before-policy example. Stratos remains backend/main-paper material unless a single illustrative sentence is needed.
- **Backend only until further verification:** site-specific Stargate SPVs/financing/incentives; Meta nuclear decomposition; Project Jupiter fuel-cell MW and permits; AEP collateral/exit protections; detailed Stratos water/power/financing; New York state-order text.

## Sweep conclusion

**The fresh record materially strengthens the physical and public/private disconnects, strengthens the demand disconnect as a question rather than a conclusion, provides named secrecy/irreversibility reporting targets, and makes capability-before-policy more concrete through permitting, tariff, utility, land and power commitments. It does not establish a new direct defense-compute pipeline or a unified national command structure.**

---

## 2026-09-30 PALANTIR / PLATFORM QUEUE ADDENDUM

### Reconciled / converted to standing boundaries
- **Palantir direct provision role:** no provision-specific Palantir award, executive-agent designation, or implementation role for §219, §1217, or §622 is established in the reviewed public record. Keep this as a standing boundary, not a recurring rediscovery task.
- **Catch and Revoke:** Palantir's denial that it operates the State Department system is preserved. Do not collapse Catch and Revoke and ICE ImmigrationOS into one platform claim.
- **Palantir structural presence:** Maven, Army Enterprise Agreement, NGC2 / Foundry, ImmigrationOS, and the Israel MoD relationship are now part of the documented backend and should not be rhetorically reduced to “mere adjacency.”

### New / sharpened open questions

| ID | Priority | Topic | Question | Evidence needed | Best source classes | Current edge | Destination if resolved | Resolution test |
|---|---|---|---|---|---|---|---|---|
| Q-029 | HIGH | §219 / §1217 implementation | If either defense-technology pathway is implemented, which executive agent, programs of record, procurement vehicles, vendors, platforms, joint ventures, or licensing structures actually carry it out? | Designation records; implementation plans; solicitations; task orders; program documents. | DoD; Army; congressional reporting; SAM.gov; budget exhibits; GAO/IG. | REL-062; WDC-028 | Relationship / Claim / Timeline | Move from adjacency to a named implementation edge only if a direct record exists. |
| Q-030 | HIGH | §622 intelligence-sharing mechanism | What systems, liaison channels, data products, query arrangements, or vendors actually mediate the expanded sharing contemplated by §622 if enacted? | Implementing guidance; system architecture; procurement; oversight; audit records. | DNI; DoD; congressional intel committees; GAO/IG; court/FOIA where available. | REL-063; WDC-031 | Relationship / What Doesn't Click | Identify actual implementation layer without inferring vendor role from capability alone. |
| Q-031 | HIGH | State / ICE program handoffs | How do State Department immigration/visa actions, DHS/ICE enforcement systems, and contractor platforms exchange leads, records, classifications, or referrals in practice? | Data-sharing agreements; PIAs; SORNs; interface docs; case-flow records; audit logs. | State; DHS/ICE; Federal Register; litigation; IG/congressional records. | REL-064; WDC-029 | Relationship / Decision-rights analysis | Establish specific handoffs and authorities, or preserve separation if none found. |
| Q-032 | HIGH | Palantir military decision rights | Within Maven, NGC2, and enterprise Army deployments, who can add data, change permissions, create models/classifications, query across domains, audit users, override outputs, and terminate or migrate the platform? | User-role matrices; ATO/architecture docs; data inventories; contract clauses; audit/exit terms. | DoD/Army; GAO; IG; procurement records; technical program docs. | REL-057–059; WDC-030 | Claim / Relationship / Decision-rights map | Convert structural presence into a legible decision-rights map without claiming universal access. |
| Q-033 | MEDIUM | Israel MoD deployment scope | What Palantir products, data sources, user groups, mission categories, and operating boundaries are actually covered by the Israel MoD wartime partnership? | Contract / procurement records; official statements; technical evidence; credible investigative reporting; denials. | Israel MoD; Palantir filings; court/procurement records; high-quality reporting. | REL-061; CLM-090 | Claim / Relationship | Differentiate documented deployment from disputed named-system attribution. |

### Queue discipline
Do not reopen the broad question “Is Palantir relevant?” The documented answer is yes at the level of institutional and technical architecture. The remaining work is narrower: **where exactly does relevance become implementation, access, decision right, or data flow?**



---

## 2026-10-02 POLITICAL-FINANCE / PASS 2C QUEUE ADDENDUM

### Closed / converted to standing boundaries

- **AIPAC PAC is not data-center industry money.** Keep Pass 2A as a separate federal electoral-support overlay.
- **Federal jurisdictional representation is not project facilitation.** Do not relabel a senator or representative as a facilitator without a documented project-specific action.
- **Georgia Power → Georgians First** is a leadership-committee relationship, not a direct Kemp candidate-committee contribution.
- **IBEW Local 26 → Wheeler** is labor support, not QTS / Compass / Blackstone money absent separate evidence.
- **Database inaccessibility / unextracted schedules are not negative findings.**

### New / sharpened open questions

| ID | Priority | Topic | Question | Evidence needed | Best source classes | Current edge | Destination if resolved | Resolution test |
|---|---|---|---|---|---|---|---|---|
| Q-034 | HIGH | Pass 2C state/local transaction completion | Across PA, IN, IA, OH, SC, AZ, TX, GA, VA and LA, which actual facilitating officials received support from project companies, developers, utilities, executives, labor, PACs, leadership committees or relevant affiliates? | Itemized recipient schedules; donor searches; amendments; refunds; local filings. | State/local campaign-finance systems; ethics commissions; municipal clerks. | REL-066–070; WDC-037 | Claim / Relationship / Project | Enter a positive or defensible negative only after the applicable primary filing universe is actually searched. |
| Q-035 | HIGH | Data Center Coalition lobbying | Which bills, agencies, tariffs, tax programs, permitting rules, energy policies or siting issues did DCC lobby on in the relevant jurisdictions and federal period? | LDA/state lobbying filings; subject descriptions; client/firm/lobbyist records. | Senate LDA; state lobbying registries; DCC disclosures. | REL-073; WDC-036 | Source / Relationship / Claim | Convert sector-policy posture into specific lobbying edges without automatic member attribution. |
| Q-036 | HIGH | Utility / energy political-finance network | Which utilities and energy providers tied to Pass 1 projects supported or lobbied the actual facilitating officials / regulators? | Utility PAC records; executive contributions; state lobbying; PSC filings; tariff/generation proceedings. | FEC; state finance; PSCs; lobbying registries; utility disclosures. | REL-067; project ledger | Relationship / Timeline / Project | Identify legal donor, recipient, amount/date/subject and project/policy nexus. |
| Q-037 | HIGH | Developer / PE / land network | Beyond NorthPoint, which developers, project LLCs, landowners, private-equity owners, attorneys or consultants financially supported or lobbied project decision-makers? | Donor normalization; land records; project LLC ownership; lobbying/client filings; local campaign reports. | State/local finance; corporate records; SEC; land records; ethics/lobbying systems. | REL-068–070 | Relationship / Project | Establish distinct legal entities; do not merge affiliates by assumption. |
| Q-038 | HIGH | AI / semiconductor / defense-tech system-level interest | Which AI, chip, defense-tech or government-tech actors lobby for abundant domestic compute, cloud, power, permitting or defense-AI infrastructure, and where do those networks overlap with Pass 1 jurisdictions / officials? | LDA subjects; PAC/executive finance; procurement policy advocacy; trade groups. | FEC; LDA; company disclosures; DoD / Commerce / DOE records. | WDC-038 | Relationship / Companion architecture | Distinguish system-level interest from project-specific support. |
| Q-039 | HIGH | Foreign-policy / national-security overlap | Beyond AIPAC PAC, which distinct PACs, defense-industry groups, bilateral technology organizations, FARA registrants or national-security policy networks support the same federal officials or lobby on intersecting AI/defense/cyber infrastructure? | FEC; LDA; FARA; lobbying client records; organization disclosures. | DOJ FARA; FEC; Senate LDA; official records. | REL-071–072 | Relationship / Network map | Preserve legal identities; do not collapse into a single “Israel money” or foreign-control category. |
| Q-040 | MEDIUM | Multi-network convergence | Which officials or policy nodes sit at three or more independently documented layers: project facilitation, industry/utility/developer/labor support, lobbying, AI/defense-tech interests, and federal foreign-policy networks? | Completed Q-034–039 rows with timing and evidence grades. | Evidence backend synthesis after primary verification. | DCD-4 / WDC-038 | Figure / synthesis | Map only documented edges; no suspicion ranking and no causal arrow without directional evidence. |
| Q-041 | HIGH | NorthPoint itemized transaction | What is the exact NorthPoint legal donor, contribution date, recipient committee, report schedule/transaction ID, amendment status and refund status for the reported $100,000 Shapiro contribution? | Itemized PA Schedule A row / export. | Pennsylvania Department of State campaign-finance system. | REL-069; CLM-099 | Claim / Timeline | Upgrade from C only when primary row is captured. |
| Q-042 | HIGH | IBEW / Wheeler primary row | What recipient-side Virginia transaction(s) underlie the reported $55,000 IBEW Local 26 support to Ann Wheeler in the 2023 cycle? | Virginia recipient report / transaction export; donor normalization; date(s). | Virginia campaign-finance primary records. | REL-070; CLM-100 | Claim / Timeline | Upgrade / correct amount and timing only after primary transaction capture. |
| Q-043 | HIGH | Morris 2026 Meta contribution | Does Jay Morris's 2026 Louisiana recipient filing confirm the reported $3,500 Meta contribution dated July 22, 2026, and what legal donor / committee / amendment / refund fields appear? | 2026 recipient filing and schedules. | Louisiana Ethics campaign-finance system. | Meta Hyperion project overlay | Claim / Relationship / Timeline | Promote from provisional only when recipient-side primary record is available. |

### Figure rule after DCD-4 freeze

`DCD-4_Political_Financial_Architecture.png` is frozen at A / A / C / C. Do not reopen the figure for every new lead. Reassess only if a new A- or B-grade relationship materially changes the architecture, corrects an existing callout, or alters the defined 26-of-38 federal-overlap result.
